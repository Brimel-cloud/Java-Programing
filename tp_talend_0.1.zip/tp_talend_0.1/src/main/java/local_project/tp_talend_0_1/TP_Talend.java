// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package local_project.tp_talend_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendStringUtil;
import routines.TalendDataGenerator;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: TP_Talend Purpose: <br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class TP_Talend implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "TP_Talend";
	private final String projectName = "LOCAL_PROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				TP_Talend.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(TP_Talend.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterColumns_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputXML_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputExcel_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputExcel_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputExcel_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputXML_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_1_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_1_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_1_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_2_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_2_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_2_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_3_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_3_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_3_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public long perte_ou_gain;

				public long getPerte_ou_gain () {
					return this.perte_ou_gain;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",perte_ou_gain="+String.valueOf(perte_ou_gain));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_3 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_3> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public long perte_ou_gain;

				public long getPerte_ou_gain () {
					return this.perte_ou_gain;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",perte_ou_gain="+String.valueOf(perte_ou_gain));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_3 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public Long budget_cummule;

				public Long getBudget_cummule () {
					return this.budget_cummule;
				}
				
			    public Long revenue_cumule;

				public Long getRevenue_cumule () {
					return this.revenue_cumule;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				
			    public Long Nombre_de_films;

				public Long getNombre_de_films () {
					return this.Nombre_de_films;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget_cummule = null;
           				} else {
           			    	this.budget_cummule = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue_cumule = null;
           				} else {
           			    	this.revenue_cumule = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Nombre_de_films = null;
           				} else {
           			    	this.Nombre_de_films = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget_cummule = null;
           				} else {
           			    	this.budget_cummule = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue_cumule = null;
           				} else {
           			    	this.revenue_cumule = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Nombre_de_films = null;
           				} else {
           			    	this.Nombre_de_films = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget_cummule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget_cummule);
		            	}
					
					// Long
				
						if(this.revenue_cumule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue_cumule);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
					// Long
				
						if(this.Nombre_de_films == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.Nombre_de_films);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget_cummule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget_cummule);
		            	}
					
					// Long
				
						if(this.revenue_cumule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue_cumule);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
					// Long
				
						if(this.Nombre_de_films == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.Nombre_de_films);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",budget_cummule="+String.valueOf(budget_cummule));
		sb.append(",revenue_cumule="+String.valueOf(revenue_cumule));
		sb.append(",year="+String.valueOf(year));
		sb.append(",Nombre_de_films="+String.valueOf(Nombre_de_films));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public Long budget_cummule;

				public Long getBudget_cummule () {
					return this.budget_cummule;
				}
				
			    public Long revenue_cumule;

				public Long getRevenue_cumule () {
					return this.revenue_cumule;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				
			    public Long Nombre_de_films;

				public Long getNombre_de_films () {
					return this.Nombre_de_films;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget_cummule = null;
           				} else {
           			    	this.budget_cummule = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue_cumule = null;
           				} else {
           			    	this.revenue_cumule = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Nombre_de_films = null;
           				} else {
           			    	this.Nombre_de_films = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget_cummule = null;
           				} else {
           			    	this.budget_cummule = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue_cumule = null;
           				} else {
           			    	this.revenue_cumule = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Nombre_de_films = null;
           				} else {
           			    	this.Nombre_de_films = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget_cummule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget_cummule);
		            	}
					
					// Long
				
						if(this.revenue_cumule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue_cumule);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
					// Long
				
						if(this.Nombre_de_films == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.Nombre_de_films);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget_cummule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget_cummule);
		            	}
					
					// Long
				
						if(this.revenue_cumule == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue_cumule);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
					// Long
				
						if(this.Nombre_de_films == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.Nombre_de_films);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",budget_cummule="+String.valueOf(budget_cummule));
		sb.append(",revenue_cumule="+String.valueOf(revenue_cumule));
		sb.append(",year="+String.valueOf(year));
		sb.append(",Nombre_de_films="+String.valueOf(Nombre_de_films));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_2 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_2> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class sheet1Struct implements routines.system.IPersistableRow<sheet1Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final sheet1Struct other = (sheet1Struct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(sheet1Struct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            
	}

	public void copyKeysDataTo(sheet1Struct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(sheet1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class Page2Struct implements routines.system.IPersistableRow<Page2Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(Page2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class page3Struct implements routines.system.IPersistableRow<page3Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public long perte_ou_gain;

				public long getPerte_ou_gain () {
					return this.perte_ou_gain;
				}
				
			    public int year;

				public int getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.Title = readString(dis);
					
			        this.perte_ou_gain = dis.readLong();
					
			        this.year = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Title,dos);
					
					// long
				
		            	dos.writeLong(this.perte_ou_gain);
					
					// int
				
		            	dos.writeInt(this.year);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Title="+Title);
		sb.append(",perte_ou_gain="+String.valueOf(perte_ou_gain));
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(page3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row13Struct other = (row13Struct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row13Struct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(row13Struct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row14Struct other = (row14Struct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row14Struct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(row14Struct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row10Struct other = (row10Struct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row10Struct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(row10Struct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final OnRowsEndStructtSortRow_1 other = (OnRowsEndStructtSortRow_1) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(OnRowsEndStructtSortRow_1 other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(OnRowsEndStructtSortRow_1 other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_1 other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class moviesOutputStruct implements routines.system.IPersistableRow<moviesOutputStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID;

				public Integer getID () {
					return this.ID;
				}
				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}
				
			    public java.util.Date Release;

				public java.util.Date getRelease () {
					return this.Release;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final moviesOutputStruct other = (moviesOutputStruct) obj;
		
						if (this.ID == null) {
							if (other.ID != null)
								return false;
						
						} else if (!this.ID.equals(other.ID))
						
							return false;
					

		return true;
    }

	public void copyDataTo(moviesOutputStruct other) {

		other.ID = this.ID;
	            other.Title = this.Title;
	            other.Release = this.Release;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(moviesOutputStruct other) {

		other.ID = this.ID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.ID = readInteger(dis);
					
					this.Title = readString(dis);
					
					this.Release = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// java.util.Date
				
						writeDate(this.Release,dos);
					
					// Long
				
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
					// Long
				
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
					// Float
				
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
					// Float
				
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					// Integer
				
						writeInteger(this.vote_count1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",Title="+Title);
		sb.append(",Release="+String.valueOf(Release));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(moviesOutputStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];

	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",G="+String.valueOf(G));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.G = this.G;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",G="+String.valueOf(G));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				
			    public String errorMessage;

				public String getErrorMessage () {
					return this.errorMessage;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row16Struct other = (row16Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row16Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.G = this.G;
	            other.errorMessage = this.errorMessage;
	            
	}

	public void copyKeysDataTo(row16Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
					this.errorMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
					this.errorMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// String
				
						writeString(this.errorMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// String
				
						writeString(this.errorMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",G="+String.valueOf(G));
		sb.append(",errorMessage="+errorMessage);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.G = this.G;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",G="+String.valueOf(G));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.G = this.G;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
					this.G = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",G="+String.valueOf(G));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public Integer C;

				public Integer getC () {
					return this.C;
				}
				
			    public String D;

				public String getD () {
					return this.D;
				}
				
			    public String E;

				public String getE () {
					return this.E;
				}
				
			    public String F;

				public String getF () {
					return this.F;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				
			    public Integer H;

				public Integer getH () {
					return this.H;
				}
				
			    public Integer I;

				public Integer getI () {
					return this.I;
				}
				
			    public String J;

				public String getJ () {
					return this.J;
				}
				
			    public String K;

				public String getK () {
					return this.K;
				}
				
			    public String L;

				public String getL () {
					return this.L;
				}
				
			    public Integer M;

				public Integer getM () {
					return this.M;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row12Struct other = (row12Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row12Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.C = this.C;
	            other.D = this.D;
	            other.E = this.E;
	            other.F = this.F;
	            other.G = this.G;
	            other.H = this.H;
	            other.I = this.I;
	            other.J = this.J;
	            other.K = this.K;
	            other.L = this.L;
	            other.M = this.M;
	            
	}

	public void copyKeysDataTo(row12Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",C="+String.valueOf(C));
		sb.append(",D="+D);
		sb.append(",E="+E);
		sb.append(",F="+F);
		sb.append(",G="+String.valueOf(G));
		sb.append(",H="+String.valueOf(H));
		sb.append(",I="+String.valueOf(I));
		sb.append(",J="+J);
		sb.append(",K="+K);
		sb.append(",L="+L);
		sb.append(",M="+String.valueOf(M));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public Integer C;

				public Integer getC () {
					return this.C;
				}
				
			    public String D;

				public String getD () {
					return this.D;
				}
				
			    public String E;

				public String getE () {
					return this.E;
				}
				
			    public String F;

				public String getF () {
					return this.F;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				
			    public Integer H;

				public Integer getH () {
					return this.H;
				}
				
			    public Integer I;

				public Integer getI () {
					return this.I;
				}
				
			    public String J;

				public String getJ () {
					return this.J;
				}
				
			    public String K;

				public String getK () {
					return this.K;
				}
				
			    public String L;

				public String getL () {
					return this.L;
				}
				
			    public Integer M;

				public Integer getM () {
					return this.M;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.C = this.C;
	            other.D = this.D;
	            other.E = this.E;
	            other.F = this.F;
	            other.G = this.G;
	            other.H = this.H;
	            other.I = this.I;
	            other.J = this.J;
	            other.K = this.K;
	            other.L = this.L;
	            other.M = this.M;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",C="+String.valueOf(C));
		sb.append(",D="+D);
		sb.append(",E="+E);
		sb.append(",F="+F);
		sb.append(",G="+String.valueOf(G));
		sb.append(",H="+String.valueOf(H));
		sb.append(",I="+String.valueOf(I));
		sb.append(",J="+J);
		sb.append(",K="+K);
		sb.append(",L="+L);
		sb.append(",M="+String.valueOf(M));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tFileInputExcel_1Struct implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer A;

				public Integer getA () {
					return this.A;
				}
				
			    public String B;

				public String getB () {
					return this.B;
				}
				
			    public Integer C;

				public Integer getC () {
					return this.C;
				}
				
			    public String D;

				public String getD () {
					return this.D;
				}
				
			    public String E;

				public String getE () {
					return this.E;
				}
				
			    public String F;

				public String getF () {
					return this.F;
				}
				
			    public java.util.Date G;

				public java.util.Date getG () {
					return this.G;
				}
				
			    public Integer H;

				public Integer getH () {
					return this.H;
				}
				
			    public Integer I;

				public Integer getI () {
					return this.I;
				}
				
			    public String J;

				public String getJ () {
					return this.J;
				}
				
			    public String K;

				public String getK () {
					return this.K;
				}
				
			    public String L;

				public String getL () {
					return this.L;
				}
				
			    public Integer M;

				public Integer getM () {
					return this.M;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.A == null) ? 0 : this.A.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final after_tFileInputExcel_1Struct other = (after_tFileInputExcel_1Struct) obj;
		
						if (this.A == null) {
							if (other.A != null)
								return false;
						
						} else if (!this.A.equals(other.A))
						
							return false;
					

		return true;
    }

	public void copyDataTo(after_tFileInputExcel_1Struct other) {

		other.A = this.A;
	            other.B = this.B;
	            other.C = this.C;
	            other.D = this.D;
	            other.E = this.E;
	            other.F = this.F;
	            other.G = this.G;
	            other.H = this.H;
	            other.I = this.I;
	            other.J = this.J;
	            other.K = this.K;
	            other.L = this.L;
	            other.M = this.M;
	            
	}

	public void copyKeysDataTo(after_tFileInputExcel_1Struct other) {

		other.A = this.A;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.A = readInteger(dis);
					
					this.B = readString(dis);
					
						this.C = readInteger(dis);
					
					this.D = readString(dis);
					
					this.E = readString(dis);
					
					this.F = readString(dis);
					
					this.G = readDate(dis);
					
						this.H = readInteger(dis);
					
						this.I = readInteger(dis);
					
					this.J = readString(dis);
					
					this.K = readString(dis);
					
					this.L = readString(dis);
					
						this.M = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.A,dos);
					
					// String
				
						writeString(this.B,dos);
					
					// Integer
				
						writeInteger(this.C,dos);
					
					// String
				
						writeString(this.D,dos);
					
					// String
				
						writeString(this.E,dos);
					
					// String
				
						writeString(this.F,dos);
					
					// java.util.Date
				
						writeDate(this.G,dos);
					
					// Integer
				
						writeInteger(this.H,dos);
					
					// Integer
				
						writeInteger(this.I,dos);
					
					// String
				
						writeString(this.J,dos);
					
					// String
				
						writeString(this.K,dos);
					
					// String
				
						writeString(this.L,dos);
					
					// Integer
				
						writeInteger(this.M,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("A="+String.valueOf(A));
		sb.append(",B="+B);
		sb.append(",C="+String.valueOf(C));
		sb.append(",D="+D);
		sb.append(",E="+E);
		sb.append(",F="+F);
		sb.append(",G="+String.valueOf(G));
		sb.append(",H="+String.valueOf(H));
		sb.append(",I="+String.valueOf(I));
		sb.append(",J="+J);
		sb.append(",K="+K);
		sb.append(",L="+L);
		sb.append(",M="+String.valueOf(M));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tFileInputExcel_1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.A, other.A);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tFileInputDelimited_1Process(globalMap);
		tFileInputXML_1Process(globalMap);

		row1Struct row1 = new row1Struct();
row1Struct row12 = row1;
row2Struct row2 = new row2Struct();
row2Struct row4 = row2;
row5Struct row5 = new row5Struct();
row5Struct row3 = row5;
moviesOutputStruct moviesOutput = new moviesOutputStruct();
moviesOutputStruct row9 = moviesOutput;
row10Struct row10 = new row10Struct();
row10Struct row13 = row10;
row10Struct row14 = row10;
row10Struct row15 = row10;
sheet1Struct sheet1 = new sheet1Struct();
Page2Struct Page2 = new Page2Struct();
row17Struct row17 = new row17Struct();
row18Struct row18 = new row18Struct();
page3Struct page3 = new page3Struct();
row19Struct row19 = new row19Struct();
row16Struct row16 = new row16Struct();











	
	/**
	 * [tSortRow_1_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortOut", false);
		start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tSortRow_1_SortOut = 0;
		


class Comparablerow9Struct extends row9Struct implements Comparable<Comparablerow9Struct> {
	
	public int compareTo(Comparablerow9Struct other) {

		if(this.Title == null && other.Title != null){
			return -1;
						
		}else if(this.Title != null && other.Title == null){
			return 1;
						
		}else if(this.Title != null && other.Title != null){
			if(!this.Title.equals(other.Title)){
				return this.Title.compareTo(other.Title);
			}
		}
		return 0;
	}
}

java.util.List<Comparablerow9Struct> list_tSortRow_1_SortOut = new java.util.ArrayList<Comparablerow9Struct>();


 



/**
 * [tSortRow_1_SortOut begin ] stop
 */



	
	/**
	 * [tLogRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_4", false);
		start_Hash.put("tLogRow_4", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"moviesOutput");
					}
				
		int tos_count_tLogRow_4 = 0;
		

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_tLogRow_4 = "|";
		java.io.PrintStream consoleOut_tLogRow_4 = null;	

 		StringBuilder strBuffer_tLogRow_4 = null;
		int nb_line_tLogRow_4 = 0;
///////////////////////    			



 



/**
 * [tLogRow_4 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tMap_2 = 0;
		




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
					globalMap.get( "tHash_Lookup_row8" ))
					;					
					
	

row8Struct row8HashKey = new row8Struct();
row8Struct row8Default = new row8Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
					globalMap.get( "tHash_Lookup_row11" ))
					;					
					
	

row11Struct row11HashKey = new row11Struct();
row11Struct row11Default = new row11Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
moviesOutputStruct moviesOutput_tmp = new moviesOutputStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tLogRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_5", false);
		start_Hash.put("tLogRow_5", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tLogRow_5 = 0;
		

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_tLogRow_5 = "|";
		java.io.PrintStream consoleOut_tLogRow_5 = null;	

 		StringBuilder strBuffer_tLogRow_5 = null;
		int nb_line_tLogRow_5 = 0;
///////////////////////    			



 



/**
 * [tLogRow_5 begin ] stop
 */




	
	/**
	 * [tFileOutputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_2", false);
		start_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row16");
					}
				
		int tos_count_tFileOutputDelimited_2 = 0;
		

String fileName_tFileOutputDelimited_2 = "";
    fileName_tFileOutputDelimited_2 = (new java.io.File("C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/old_films.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_2 = null;
    String extension_tFileOutputDelimited_2 = null;
    String directory_tFileOutputDelimited_2 = null;
    if((fileName_tFileOutputDelimited_2.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") < fileName_tFileOutputDelimited_2.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        }
        directory_tFileOutputDelimited_2 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_2 = true;
    java.io.File filetFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
    globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
        if(filetFileOutputDelimited_2.exists()){
            isFileGenerated_tFileOutputDelimited_2 = false;
        }
            int nb_line_tFileOutputDelimited_2 = 0;
            int splitedFileNo_tFileOutputDelimited_2 = 0;
            int currentRow_tFileOutputDelimited_2 = 0;

            final String OUT_DELIM_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_2:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_2:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_2 != null && directory_tFileOutputDelimited_2.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_2 = new java.io.File(directory_tFileOutputDelimited_2);
                        if(!dir_tFileOutputDelimited_2.exists()) {
                            dir_tFileOutputDelimited_2.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_2 = null;

                        outtFileOutputDelimited_2 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_2, true),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimited_2", outtFileOutputDelimited_2);
resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

 



/**
 * [tFileOutputDelimited_2 begin ] stop
 */



	
	/**
	 * [tFilterRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_2", false);
		start_Hash.put("tFilterRow_2", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tFilterRow_2 = 0;
		
    int nb_line_tFilterRow_2 = 0;
    int nb_line_ok_tFilterRow_2 = 0;
    int nb_line_reject_tFilterRow_2 = 0;

    class Operator_tFilterRow_2 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_2(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_2 begin ] stop
 */



	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tLogRow_1 = 0;
		

 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tFilterColumns_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterColumns_1", false);
		start_Hash.put("tFilterColumns_1", System.currentTimeMillis());
		
	
	currentComponent="tFilterColumns_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row12");
					}
				
		int tos_count_tFilterColumns_1 = 0;
		


 int nb_line_tFilterColumns_1 = 0;
 



/**
 * [tFilterColumns_1 begin ] stop
 */



	
	/**
	 * [tLogRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_6", false);
		start_Hash.put("tLogRow_6", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tLogRow_6 = 0;
		

 



/**
 * [tLogRow_6 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";

	
		int tos_count_tFileInputExcel_1 = 0;
		



			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

			        if(useRegex){//this part process the regex issue

				        jxl.Sheet[] sheets = workbook.getSheets();
				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (int i = 0; i < sheets.length; i++) {
				            String sheetName = sheets[i].getName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	jxl.Sheet sheet = workbook.getSheet(sheetName);
				            	if(sheet != null){
				                	list.add(sheet);
				                }
				            }
				        }

			        }else{
			        	jxl.Sheet sheet = workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
			    	java.util.List<jxl.Sheet> list =  new java.util.ArrayList<jxl.Sheet>();
			    	jxl.Sheet sheet = workbook.getSheet(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}


		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
		final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
		workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
        workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

        Object source_tFileInputExcel_1 ="C:/Users/GLC/Downloads/moviesRelease.xls";
        final jxl.Workbook workbook_tFileInputExcel_1;

        java.io.InputStream toClose_tFileInputExcel_1 = null;
        java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
        try {
            if(source_tFileInputExcel_1 instanceof java.io.InputStream){
        		toClose_tFileInputExcel_1 = (java.io.InputStream)source_tFileInputExcel_1;
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else if(source_tFileInputExcel_1 instanceof String){
        		toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else{
            	workbook_tFileInputExcel_1 = null;
            	throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
            }
        } finally {
			try{
			   if(buffIStreamtFileInputExcel_1 != null){
			   	  buffIStreamtFileInputExcel_1.close();
			   }
			}catch(Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			}
        }
        try {
		java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet> asList(workbook_tFileInputExcel_1.getSheets());
        if(sheetList_tFileInputExcel_1.size() <= 0){
        	throw new RuntimeException("Special sheets not exist!");
        }

        java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
        for(jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1){
        	if(sheet_FilterNull_tFileInputExcel_1.getRows()>0){
        		sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
        	}
        }
		sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
	if(sheetList_tFileInputExcel_1.size()>0){
        int nb_line_tFileInputExcel_1 = 0;

        int begin_line_tFileInputExcel_1 = 0;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(jxl.Sheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
        	end_line_tFileInputExcel_1+=sheet_tFileInputExcel_1.getRows();
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
        jxl.Cell[] row_tFileInputExcel_1 = null;
        jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

        //for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
		char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
		
		
		
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
            }
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
        	globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getName());
    		row1 = null;
					int tempRowLength_tFileInputExcel_1 = 13;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
//
//end%>
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	row_tFileInputExcel_1.length ? row_tFileInputExcel_1.length : end_column_tFileInputExcel_1;

				java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
                java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat("dd-MM-yyyy");
                sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);
                

			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){

				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){

				  jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i + start_column_tFileInputExcel_1];
                        temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}

			boolean whetherReject_tFileInputExcel_1 = false;
			row1 = new row1Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try {
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "A";
			row1.A = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row1.A = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "B";
			row1.B = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.B = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 2;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "C";
			row1.C = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row1.C = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 3;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "D";
			row1.D = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.D = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 4;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "E";
			row1.E = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.E = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 5;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "F";
			row1.F = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.F = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 6;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "G";
			if(6<actual_end_column_tFileInputExcel_1){
				try{
					java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell)row_tFileInputExcel_1[columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1]).getDate();
					row1.G = new java.util.Date(dateGMT_tFileInputExcel_1.getTime() - java.util.TimeZone.getDefault().getOffset(dateGMT_tFileInputExcel_1.getTime()));
				}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
					
					throw new RuntimeException("The cell format is not Date in ( Row. "+(nb_line_tFileInputExcel_1+1)+ " and ColumnNum. " + curColNum_tFileInputExcel_1 + " )");
				}
			}
			}else {
				row1.G = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 7;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "H";
			row1.H = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row1.H = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 8;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "I";
			row1.I = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row1.I = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 9;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "J";
			row1.J = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.J = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 10;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "K";
			row1.K = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.K = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 11;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "L";
			row1.L = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row1.L = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 12;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "M";
			row1.M = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row1.M = null;
				emptyColumnCount_tFileInputExcel_1++;
		}

			nb_line_tFileInputExcel_1++;
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputExcel_1 = true;
                System.err.println(e.getMessage());
                row1 = null;
    }

					
		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tLogRow_6 main ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					

 
     row12 = row1;


	tos_count_tLogRow_6++;

/**
 * [tLogRow_6 main ] stop
 */
	
	/**
	 * [tLogRow_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 process_data_begin ] stop
 */

	
	/**
	 * [tFilterColumns_1 main ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row12"
						
						);
					}
					
	

	row2.A = row12.A;

	
	row2.B = row12.B;

	
	row2.G = row12.G;

	
    nb_line_tFilterColumns_1++;

 


	tos_count_tFilterColumns_1++;

/**
 * [tFilterColumns_1 main ] stop
 */
	
	/**
	 * [tFilterColumns_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

 



/**
 * [tFilterColumns_1 process_data_begin ] stop
 */

	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

 
     row4 = row2;


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */

	
	/**
	 * [tFilterRow_2 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					

          row16 = null;
          row5 = null;
    Operator_tFilterRow_2 ope_tFilterRow_2 = new Operator_tFilterRow_2("&&");
            ope_tFilterRow_2.matches((row4.G == null? false : row4.G.compareTo(TalendDate.parseDate("dd-MM-yyyy","31-12-1999")) >= 0)
                           , "G.compareTo(TalendDate.parseDate(\"dd-MM-yyyy\",\"31-12-1999\")) >= 0 failed");
    
    if (ope_tFilterRow_2.getMatchFlag()) {
              if(row5 == null){ 
                row5 = new row5Struct();
              }
               row5.A = row4.A;
               row5.B = row4.B;
               row5.G = row4.G;    
      nb_line_ok_tFilterRow_2++;
    } else {
            if (row16 == null){
              row16 = new row16Struct();
            }
                row16.A = row4.A;
                row16.B = row4.B;
                row16.G = row4.G;
	            row16.errorMessage = ope_tFilterRow_2.getErrorMsg();
      nb_line_reject_tFilterRow_2++;
    }

nb_line_tFilterRow_2++;

 


	tos_count_tFilterRow_2++;

/**
 * [tFilterRow_2 main ] stop
 */
	
	/**
	 * [tFilterRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tLogRow_5 main ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					
///////////////////////		
						



				strBuffer_tLogRow_5 = new StringBuilder();




   				
	    		if(row5.A != null) { //              
                    							
       
				strBuffer_tLogRow_5.append(
				                String.valueOf(row5.A)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_5.append("|");
    			


   				
	    		if(row5.B != null) { //              
                    							
       
				strBuffer_tLogRow_5.append(
				                String.valueOf(row5.B)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_5.append("|");
    			


   				
	    		if(row5.G != null) { //              
                    							
       
				strBuffer_tLogRow_5.append(
								FormatterUtils.format_Date(row5.G, "dd-MM-yyyy")				
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_5 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_5 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_5);
                    }
                    consoleOut_tLogRow_5.println(strBuffer_tLogRow_5.toString());
                    consoleOut_tLogRow_5.flush();
                    nb_line_tLogRow_5++;
//////

//////                    
                    
///////////////////////    			

 
     row3 = row5;


	tos_count_tLogRow_5++;

/**
 * [tLogRow_5 main ] stop
 */
	
	/**
	 * [tLogRow_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 process_data_begin ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row8" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow8 = false;
       		  	    	
       		  	    	
 							row8Struct row8ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_2) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_2 = false;
								
                        		    		    row8HashKey.movie_id = row3.A;
                        		    		

								
		                        	row8HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row8.lookup( row8HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row8 != null && tHash_Lookup_row8.getCount(row8HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row8' and it contains more one result from keys :  row8.movie_id = '" + row8HashKey.movie_id + "'");
								} // G 071
							

							row8Struct row8 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row8Struct fromLookup_row8 = null;
							row8 = row8Default;
										 
							
								 
							
							
								if (tHash_Lookup_row8 !=null && tHash_Lookup_row8.hasNext()) { // G 099
								
							
								
								fromLookup_row8 = tHash_Lookup_row8.next();

							
							
								} // G 099
							
							

							if(fromLookup_row8 != null) {
								row8 = fromLookup_row8;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row11" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow11 = false;
       		  	    	
       		  	    	
 							row11Struct row11ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_2) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_2 = false;
								
                        		    		    row11HashKey.title1 = row3.B;
                        		    		

								
		                        	row11HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row11.lookup( row11HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row11 != null && tHash_Lookup_row11.getCount(row11HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row11' and it contains more one result from keys :  row11.title1 = '" + row11HashKey.title1 + "'");
								} // G 071
							

							row11Struct row11 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row11Struct fromLookup_row11 = null;
							row11 = row11Default;
										 
							
								 
							
							
								if (tHash_Lookup_row11 !=null && tHash_Lookup_row11.hasNext()) { // G 099
								
							
								
								fromLookup_row11 = tHash_Lookup_row11.next();

							
							
								} // G 099
							
							

							if(fromLookup_row11 != null) {
								row11 = fromLookup_row11;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

moviesOutput = null;


// # Output table : 'moviesOutput'
moviesOutput_tmp.ID = row8.movie_id ;
moviesOutput_tmp.Title = row3.B;
moviesOutput_tmp.Release = row3.G;
moviesOutput_tmp.budget = row8.budget ;
moviesOutput_tmp.revenue = row8.revenue ;
moviesOutput_tmp.popularity1 = row11.popularity1   ;
moviesOutput_tmp.vote_average1 = row11.vote_average1 ;
moviesOutput_tmp.vote_count1 = row11.vote_count1 ;
moviesOutput = moviesOutput_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "moviesOutput"
if(moviesOutput != null) { 



	
	/**
	 * [tLogRow_4 main ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"moviesOutput"
						
						);
					}
					
///////////////////////		
						



				strBuffer_tLogRow_4 = new StringBuilder();




   				
	    		if(moviesOutput.ID != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
				                String.valueOf(moviesOutput.ID)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.Title != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
				                String.valueOf(moviesOutput.Title)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.Release != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
								FormatterUtils.format_Date(moviesOutput.Release, "dd-MM-yyyy")				
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.budget != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
				                String.valueOf(moviesOutput.budget)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.revenue != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
				                String.valueOf(moviesOutput.revenue)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.popularity1 != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
								FormatterUtils.formatUnwithE(moviesOutput.popularity1)				
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.vote_average1 != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
								FormatterUtils.formatUnwithE(moviesOutput.vote_average1)				
				);


							
	    		} //  			

    			strBuffer_tLogRow_4.append("|");
    			


   				
	    		if(moviesOutput.vote_count1 != null) { //              
                    							
       
				strBuffer_tLogRow_4.append(
				                String.valueOf(moviesOutput.vote_count1)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_4 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_4 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_4);
                    }
                    consoleOut_tLogRow_4.println(strBuffer_tLogRow_4.toString());
                    consoleOut_tLogRow_4.flush();
                    nb_line_tLogRow_4++;
//////

//////                    
                    
///////////////////////    			

 
     row9 = moviesOutput;


	tos_count_tLogRow_4++;

/**
 * [tLogRow_4 main ] stop
 */
	
	/**
	 * [tLogRow_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	

 



/**
 * [tLogRow_4 process_data_begin ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					



	Comparablerow9Struct arrayRowtSortRow_1_SortOut = new Comparablerow9Struct();

	arrayRowtSortRow_1_SortOut.ID = row9.ID;
	arrayRowtSortRow_1_SortOut.Title = row9.Title;
	arrayRowtSortRow_1_SortOut.Release = row9.Release;
	arrayRowtSortRow_1_SortOut.budget = row9.budget;
	arrayRowtSortRow_1_SortOut.revenue = row9.revenue;
	arrayRowtSortRow_1_SortOut.popularity1 = row9.popularity1;
	arrayRowtSortRow_1_SortOut.vote_average1 = row9.vote_average1;
	arrayRowtSortRow_1_SortOut.vote_count1 = row9.vote_count1;	
	list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

 


	tos_count_tSortRow_1_SortOut++;

/**
 * [tSortRow_1_SortOut main ] stop
 */
	
	/**
	 * [tSortRow_1_SortOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut process_data_begin ] stop
 */
	
	/**
	 * [tSortRow_1_SortOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut process_data_end ] stop
 */



	
	/**
	 * [tLogRow_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	

 



/**
 * [tLogRow_4 process_data_end ] stop
 */

} // End of branch "moviesOutput"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 process_data_end ] stop
 */

} // End of branch "row5"




// Start of branch "row16"
if(row16 != null) { 



	
	/**
	 * [tFileOutputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row16"
						
						);
					}
					


                    StringBuilder sb_tFileOutputDelimited_2 = new StringBuilder();
                            if(row16.A != null) {
                        sb_tFileOutputDelimited_2.append(
                            row16.A
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(row16.B != null) {
                        sb_tFileOutputDelimited_2.append(
                            row16.B
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(row16.G != null) {
                        sb_tFileOutputDelimited_2.append(
                            FormatterUtils.format_Date(row16.G, "dd-MM-yyyy")
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(row16.errorMessage != null) {
                        sb_tFileOutputDelimited_2.append(
                            row16.errorMessage
                        );
                            }
                    sb_tFileOutputDelimited_2.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);


                    nb_line_tFileOutputDelimited_2++;
                    resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

                        outtFileOutputDelimited_2.write(sb_tFileOutputDelimited_2.toString());




 


	tos_count_tFileOutputDelimited_2++;

/**
 * [tFileOutputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	

 



/**
 * [tFileOutputDelimited_2 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	

 



/**
 * [tFileOutputDelimited_2 process_data_end ] stop
 */

} // End of branch "row16"




	
	/**
	 * [tFilterRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */



	
	/**
	 * [tFilterColumns_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

 



/**
 * [tFilterColumns_1 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

			}
			
			
			
			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
			
				}
			
		} finally { 
				
					if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
						workbook_tFileInputExcel_1.close();
					}
				
		}	
		

 

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tLogRow_6 end ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tLogRow_6", true);
end_Hash.put("tLogRow_6", System.currentTimeMillis());




/**
 * [tLogRow_6 end ] stop
 */

	
	/**
	 * [tFilterColumns_1 end ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

globalMap.put("tFilterColumns_1_NB_LINE",nb_line_tFilterColumns_1);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row12");
			  	}
			  	
 

ok_Hash.put("tFilterColumns_1", true);
end_Hash.put("tFilterColumns_1", System.currentTimeMillis());




/**
 * [tFilterColumns_1 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */

	
	/**
	 * [tFilterRow_2 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	
    globalMap.put("tFilterRow_2_NB_LINE", nb_line_tFilterRow_2);
    globalMap.put("tFilterRow_2_NB_LINE_OK", nb_line_ok_tFilterRow_2);
    globalMap.put("tFilterRow_2_NB_LINE_REJECT", nb_line_reject_tFilterRow_2);
    

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tFilterRow_2", true);
end_Hash.put("tFilterRow_2", System.currentTimeMillis());




/**
 * [tFilterRow_2 end ] stop
 */

	
	/**
	 * [tLogRow_5 end ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	


//////
//////
globalMap.put("tLogRow_5_NB_LINE",nb_line_tLogRow_5);

///////////////////////    			

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tLogRow_5", true);
end_Hash.put("tLogRow_5", System.currentTimeMillis());




/**
 * [tLogRow_5 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row8 != null) {
						tHash_Lookup_row8.endGet();
					}
					globalMap.remove( "tHash_Lookup_row8" );

					
					
				
					if(tHash_Lookup_row11 != null) {
						tHash_Lookup_row11.endGet();
					}
					globalMap.remove( "tHash_Lookup_row11" );

					
					
				
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tLogRow_4 end ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	


//////
//////
globalMap.put("tLogRow_4_NB_LINE",nb_line_tLogRow_4);

///////////////////////    			

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"moviesOutput");
			  	}
			  	
 

ok_Hash.put("tLogRow_4", true);
end_Hash.put("tLogRow_4", System.currentTimeMillis());




/**
 * [tLogRow_4 end ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

row9Struct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut.toArray(new Comparablerow9Struct[0]);

java.util.Arrays.sort(array_tSortRow_1_SortOut);

globalMap.put("tSortRow_1",array_tSortRow_1_SortOut);


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tSortRow_1_SortOut", true);
end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_1_SortOut end ] stop
 */



	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row13");
					}
				
		int tos_count_tFileOutputDelimited_1 = 0;
		

String fileName_tFileOutputDelimited_1 = "";
    fileName_tFileOutputDelimited_1 = (new java.io.File("C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question4.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_1 = null;
    String extension_tFileOutputDelimited_1 = null;
    String directory_tFileOutputDelimited_1 = null;
    if((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        }
        directory_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_1 = true;
    java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
    globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
        if(filetFileOutputDelimited_1.exists()){
            isFileGenerated_tFileOutputDelimited_1 = false;
        }
            int nb_line_tFileOutputDelimited_1 = 0;
            int splitedFileNo_tFileOutputDelimited_1 = 0;
            int currentRow_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */"„,"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
                        if(!dir_tFileOutputDelimited_1.exists()) {
                            dir_tFileOutputDelimited_1.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_1 = null;

                        outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, true),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_1.length()==0){
                                        outtFileOutputDelimited_1.write("ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Release");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("budget");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("revenue");
                                        outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */




	
	/**
	 * [tFileOutputXML_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputXML_1", false);
		start_Hash.put("tFileOutputXML_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputXML_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row14");
					}
				
		int tos_count_tFileOutputXML_1 = 0;
		


	String originalFileName_tFileOutputXML_1 = "C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question5.xml";
	java.io.File originalFile_tFileOutputXML_1 = new java.io.File(originalFileName_tFileOutputXML_1); 

	String fileName_tFileOutputXML_1 = originalFileName_tFileOutputXML_1;
	java.io.File file_tFileOutputXML_1 = new java.io.File(fileName_tFileOutputXML_1); 
	if(!file_tFileOutputXML_1.isAbsolute()) {
		file_tFileOutputXML_1 = file_tFileOutputXML_1.getCanonicalFile();
	}

	//create directory only if not exists
	
	file_tFileOutputXML_1.getParentFile().mkdirs();
	
	String[] headers_tFileOutputXML_1 = new String[2];
		
	headers_tFileOutputXML_1[0] = "<?xml version=\"1.0\" encoding=\""+"ISO-8859-15"+"\"?>";  

	String[] footers_tFileOutputXML_1 = new String[1];

	headers_tFileOutputXML_1[1] = "<"+"root"+">";

	footers_tFileOutputXML_1[0] = "</"+"root"+">";


	int nb_line_tFileOutputXML_1 = 0;

	java.io.BufferedWriter out_tFileOutputXML_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(file_tFileOutputXML_1), "ISO-8859-15"));
	

	out_tFileOutputXML_1.write(headers_tFileOutputXML_1[0]);
	out_tFileOutputXML_1.newLine();	
	out_tFileOutputXML_1.write(headers_tFileOutputXML_1[1]);
	out_tFileOutputXML_1.newLine();	

 



/**
 * [tFileOutputXML_1 begin ] stop
 */





	
	/**
	 * [tFileOutputExcel_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputExcel_2", false);
		start_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputExcel_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"sheet1");
					}
				
		int tos_count_tFileOutputExcel_2 = 0;
		


		
		int columnIndex_tFileOutputExcel_2 = 0;
		boolean headerIsInserted_tFileOutputExcel_2 = false;
		
		
		int nb_line_tFileOutputExcel_2 = 0;

		String fileName_tFileOutputExcel_2="C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question6.xls";
		java.io.File file_tFileOutputExcel_2 = new java.io.File(fileName_tFileOutputExcel_2);
		boolean isFileGenerated_tFileOutputExcel_2 = true;
//create directory only if not exists
          java.io.File parentFile_tFileOutputExcel_2 = file_tFileOutputExcel_2.getParentFile();
          if (parentFile_tFileOutputExcel_2 != null && !parentFile_tFileOutputExcel_2.exists()) {
        	
             parentFile_tFileOutputExcel_2.mkdirs();
        	
          }

		jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_2 = null;
		jxl.write.WritableSheet writableSheet_tFileOutputExcel_2 = null;

		jxl.WorkbookSettings workbookSettings_tFileOutputExcel_2 = new jxl.WorkbookSettings();
        workbookSettings_tFileOutputExcel_2.setEncoding("ISO-8859-15");
		writeableWorkbook_tFileOutputExcel_2 = new jxl.write.biff.WritableWorkbookImpl(
            		new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_2)),
            		true,
            		workbookSettings_tFileOutputExcel_2);

        writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.getSheet("Sheet1");
        if(writableSheet_tFileOutputExcel_2 == null){
        	writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.createSheet("Sheet1", writeableWorkbook_tFileOutputExcel_2.getNumberOfSheets());
		}


        //modif start
        int startRowNum_tFileOutputExcel_2 = writableSheet_tFileOutputExcel_2.getRows();
		//modif end

		int[] fitWidth_tFileOutputExcel_2 = new int[5];
		for(int i_tFileOutputExcel_2=0;i_tFileOutputExcel_2<5;i_tFileOutputExcel_2++){
		    int fitCellViewSize_tFileOutputExcel_2=writableSheet_tFileOutputExcel_2.getColumnView(i_tFileOutputExcel_2).getSize();
			fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2]=fitCellViewSize_tFileOutputExcel_2/256;
			if(fitCellViewSize_tFileOutputExcel_2%256!=0){
				fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2]+=1;
			}
		}

						final jxl.write.WritableCellFormat cell_format_Release_tFileOutputExcel_2=new jxl.write.WritableCellFormat(new jxl.write.DateFormat("dd-MM-yyyy"));


		if (startRowNum_tFileOutputExcel_2 == 0){
	//modif end
		//modif start
			writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_2, "ID"
			));
		//modif end
		fitWidth_tFileOutputExcel_2[0]=fitWidth_tFileOutputExcel_2[0]>2?fitWidth_tFileOutputExcel_2[0]:2;
		//modif start
			writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_2, "Title"
			));
		//modif end
		fitWidth_tFileOutputExcel_2[1]=fitWidth_tFileOutputExcel_2[1]>5?fitWidth_tFileOutputExcel_2[1]:5;
		//modif start
			writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_2, "Release"
			));
		//modif end
		fitWidth_tFileOutputExcel_2[2]=fitWidth_tFileOutputExcel_2[2]>7?fitWidth_tFileOutputExcel_2[2]:7;
		//modif start
			writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_2, "budget"
			));
		//modif end
		fitWidth_tFileOutputExcel_2[3]=fitWidth_tFileOutputExcel_2[3]>6?fitWidth_tFileOutputExcel_2[3]:6;
		//modif start
			writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_2, "revenue"
			));
		//modif end
		fitWidth_tFileOutputExcel_2[4]=fitWidth_tFileOutputExcel_2[4]>7?fitWidth_tFileOutputExcel_2[4]:7;
		nb_line_tFileOutputExcel_2 ++;
		headerIsInserted_tFileOutputExcel_2 = true;
	}


 



/**
 * [tFileOutputExcel_2 begin ] stop
 */




	
	/**
	 * [tSortRow_2_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortOut", false);
		start_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"Page2");
					}
				
		int tos_count_tSortRow_2_SortOut = 0;
		


class ComparablePage2Struct extends Page2Struct implements Comparable<ComparablePage2Struct> {
	
	public int compareTo(ComparablePage2Struct other) {

		if(this.year != other.year){
						
				return this.year > other.year ? 1 : -1;
							
		}
		return 0;
	}
}

java.util.List<ComparablePage2Struct> list_tSortRow_2_SortOut = new java.util.ArrayList<ComparablePage2Struct>();


 



/**
 * [tSortRow_2_SortOut begin ] stop
 */




	
	/**
	 * [tSortRow_3_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_3_SortOut", false);
		start_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"page3");
					}
				
		int tos_count_tSortRow_3_SortOut = 0;
		


class Comparablepage3Struct extends page3Struct implements Comparable<Comparablepage3Struct> {
	
	public int compareTo(Comparablepage3Struct other) {

		if(this.perte_ou_gain != other.perte_ou_gain){
						
				return this.perte_ou_gain > other.perte_ou_gain ? 1 : -1;
							
		}
		return 0;
	}
}

java.util.List<Comparablepage3Struct> list_tSortRow_3_SortOut = new java.util.ArrayList<Comparablepage3Struct>();


 



/**
 * [tSortRow_3_SortOut begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row15");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
	int year;
	long perte_ou_gain;
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
sheet1Struct sheet1_tmp = new sheet1Struct();
Page2Struct Page2_tmp = new Page2Struct();
page3Struct page3_tmp = new page3Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileOutputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputExcel_1", false);
		start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputExcel_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row10");
					}
				
		int tos_count_tFileOutputExcel_1 = 0;
		


		
		int columnIndex_tFileOutputExcel_1 = 0;
		boolean headerIsInserted_tFileOutputExcel_1 = false;
		
		
		int nb_line_tFileOutputExcel_1 = 0;

		String fileName_tFileOutputExcel_1="C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question3.xls";
		java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
		boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
          java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
          if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {
        	
             parentFile_tFileOutputExcel_1.mkdirs();
        	
          }

		jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
		jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

		jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
        workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
		writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
            		new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
            		true,
            		workbookSettings_tFileOutputExcel_1);

        writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("Sheet1");
        if(writableSheet_tFileOutputExcel_1 == null){
        	writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("Sheet1", writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
		}


        //modif start
        int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
		//modif end

		int[] fitWidth_tFileOutputExcel_1 = new int[8];
		for(int i_tFileOutputExcel_1=0;i_tFileOutputExcel_1<8;i_tFileOutputExcel_1++){
		    int fitCellViewSize_tFileOutputExcel_1=writableSheet_tFileOutputExcel_1.getColumnView(i_tFileOutputExcel_1).getSize();
			fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1]=fitCellViewSize_tFileOutputExcel_1/256;
			if(fitCellViewSize_tFileOutputExcel_1%256!=0){
				fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1]+=1;
			}
		}

						final jxl.write.WritableCellFormat cell_format_Release_tFileOutputExcel_1=new jxl.write.WritableCellFormat(new jxl.write.DateFormat("dd-MM-yyyy"));


		if (startRowNum_tFileOutputExcel_1 == 0){
	//modif end
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_1, "ID"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[0]=fitWidth_tFileOutputExcel_1[0]>2?fitWidth_tFileOutputExcel_1[0]:2;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_1, "Title"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[1]=fitWidth_tFileOutputExcel_1[1]>5?fitWidth_tFileOutputExcel_1[1]:5;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_1, "Release"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[2]=fitWidth_tFileOutputExcel_1[2]>7?fitWidth_tFileOutputExcel_1[2]:7;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_1, "budget"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[3]=fitWidth_tFileOutputExcel_1[3]>6?fitWidth_tFileOutputExcel_1[3]:6;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_1, "revenue"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[4]=fitWidth_tFileOutputExcel_1[4]>7?fitWidth_tFileOutputExcel_1[4]:7;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_1, "popularity1"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[5]=fitWidth_tFileOutputExcel_1[5]>11?fitWidth_tFileOutputExcel_1[5]:11;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_1, "vote_average1"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[6]=fitWidth_tFileOutputExcel_1[6]>13?fitWidth_tFileOutputExcel_1[6]:13;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_1, "vote_count1"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[7]=fitWidth_tFileOutputExcel_1[7]>11?fitWidth_tFileOutputExcel_1[7]:11;
		nb_line_tFileOutputExcel_1 ++;
		headerIsInserted_tFileOutputExcel_1 = true;
	}


 



/**
 * [tFileOutputExcel_1 begin ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortIn", false);
		start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	
		int tos_count_tSortRow_1_SortIn = 0;
		


row9Struct[] array_tSortRow_1_SortIn = (row9Struct[]) globalMap.remove("tSortRow_1");

int nb_line_tSortRow_1_SortIn = 0;

row9Struct current_tSortRow_1_SortIn = null;

for(int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++){
	current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
	row10.ID = current_tSortRow_1_SortIn.ID;
	row10.Title = current_tSortRow_1_SortIn.Title;
	row10.Release = current_tSortRow_1_SortIn.Release;
	row10.budget = current_tSortRow_1_SortIn.budget;
	row10.revenue = current_tSortRow_1_SortIn.revenue;
	row10.popularity1 = current_tSortRow_1_SortIn.popularity1;
	row10.vote_average1 = current_tSortRow_1_SortIn.vote_average1;
	row10.vote_count1 = current_tSortRow_1_SortIn.vote_count1;
	// increase number of line sorted
	nb_line_tSortRow_1_SortIn++;

 



/**
 * [tSortRow_1_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 


	tos_count_tSortRow_1_SortIn++;

/**
 * [tSortRow_1_SortIn main ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row10"
						
						);
					}
					

								   				
	    				if(row10.ID != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 0;
					

					
						jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.ID
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
							int currentWith_0_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_0_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_1=currentWith_0_tFileOutputExcel_1>10?10:currentWith_0_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[0]=fitWidth_tFileOutputExcel_1[0]>currentWith_0_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[0]:currentWith_0_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.Title != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 1;
					

					
						jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.Title
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
							int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[1]=fitWidth_tFileOutputExcel_1[1]>currentWith_1_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[1]:currentWith_1_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.Release != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 2;
					

					
						jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.DateTime(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.Release, cell_format_Release_tFileOutputExcel_1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
							int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents().trim().length();
							currentWith_2_tFileOutputExcel_1=12;
							fitWidth_tFileOutputExcel_1[2]=fitWidth_tFileOutputExcel_1[2]>currentWith_2_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[2]:currentWith_2_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.budget != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 3;
					

					
						jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.budget
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
							int currentWith_3_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_3_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_3_tFileOutputExcel_1=currentWith_3_tFileOutputExcel_1>10?10:currentWith_3_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[3]=fitWidth_tFileOutputExcel_1[3]>currentWith_3_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[3]:currentWith_3_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.revenue != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 4;
					

					
						jxl.write.WritableCell cell_4_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.revenue
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_4_tFileOutputExcel_1);
							int currentWith_4_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_4_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_4_tFileOutputExcel_1=currentWith_4_tFileOutputExcel_1>10?10:currentWith_4_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[4]=fitWidth_tFileOutputExcel_1[4]>currentWith_4_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[4]:currentWith_4_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.popularity1 != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 5;
					

					
						jxl.write.WritableCell cell_5_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.popularity1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_5_tFileOutputExcel_1);
							int currentWith_5_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_5_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_5_tFileOutputExcel_1=currentWith_5_tFileOutputExcel_1>10?10:currentWith_5_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[5]=fitWidth_tFileOutputExcel_1[5]>currentWith_5_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[5]:currentWith_5_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.vote_average1 != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 6;
					

					
						jxl.write.WritableCell cell_6_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.vote_average1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_6_tFileOutputExcel_1);
							int currentWith_6_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_6_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_6_tFileOutputExcel_1=currentWith_6_tFileOutputExcel_1>10?10:currentWith_6_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[6]=fitWidth_tFileOutputExcel_1[6]>currentWith_6_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[6]:currentWith_6_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row10.vote_count1 != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 7;
					

					
						jxl.write.WritableCell cell_7_tFileOutputExcel_1 = new jxl.write.Number(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row10.vote_count1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_7_tFileOutputExcel_1);
							int currentWith_7_tFileOutputExcel_1 = String.valueOf(((jxl.write.Number)cell_7_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_7_tFileOutputExcel_1=currentWith_7_tFileOutputExcel_1>10?10:currentWith_7_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[7]=fitWidth_tFileOutputExcel_1[7]>currentWith_7_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[7]:currentWith_7_tFileOutputExcel_1+2;
	    				} 
					
    			nb_line_tFileOutputExcel_1++;
				
 
     row13 = row10;
     row14 = row10;
     row15 = row10;


	tos_count_tFileOutputExcel_1++;

/**
 * [tFileOutputExcel_1 main ] stop
 */
	
	/**
	 * [tFileOutputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row13"
						
						);
					}
					


                    StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
                            if(row13.ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            row13.ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(row13.Release != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(row13.Release, "dd-MM-yyyy")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(row13.budget != null) {
                        sb_tFileOutputDelimited_1.append(
                            row13.budget
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(row13.revenue != null) {
                        sb_tFileOutputDelimited_1.append(
                            row13.revenue
                        );
                            }
                    sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);


                    nb_line_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

                        outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_end ] stop
 */




	
	/**
	 * [tFileOutputXML_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputXML_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row14"
						
						);
					}
					

StringBuilder tempRes_tFileOutputXML_1 = new StringBuilder("<"+"row");
tempRes_tFileOutputXML_1.append(">");
out_tFileOutputXML_1.write(tempRes_tFileOutputXML_1.toString());

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"ID"+">"+((row14.ID == null)?"":(row14.ID))+"</"+"ID"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"Title"+">"+((row14.Title == null)?"":(TalendString.checkCDATAForXML(row14.Title)))+"</"+"Title"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"vote_count1"+">"+((row14.vote_count1 == null)?"":(row14.vote_count1))+"</"+"vote_count1"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"vote_average1"+">"+((row14.vote_average1 == null)?"":(row14.vote_average1))+"</"+"vote_average1"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"popularity1"+">"+((row14.popularity1 == null)?"":(row14.popularity1))+"</"+"popularity1"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("<"+"Release"+">"+((row14.Release == null)?"":(TalendString.checkCDATAForXML(FormatterUtils.format_Date(row14.Release, "dd-MM-yyyy"))))+"</"+"Release"+">");

out_tFileOutputXML_1.newLine();
out_tFileOutputXML_1.write("</"+"row"+">");

out_tFileOutputXML_1.newLine();


nb_line_tFileOutputXML_1++;



 


	tos_count_tFileOutputXML_1++;

/**
 * [tFileOutputXML_1 main ] stop
 */
	
	/**
	 * [tFileOutputXML_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputXML_1";

	

 



/**
 * [tFileOutputXML_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputXML_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputXML_1";

	

 



/**
 * [tFileOutputXML_1 process_data_end ] stop
 */




	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row15"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;
Var.year = TalendDate.getPartOfDate("YEAR",row15.Release) ;
Var.perte_ou_gain = row15.revenue -  row15.budget ;// ###############################
        // ###############################
        // # Output tables

sheet1 = null;
Page2 = null;
page3 = null;


// # Output table : 'sheet1'
sheet1_tmp.ID = row15.ID ;
sheet1_tmp.Title = row15.Title ;
sheet1_tmp.Release = row15.Release ;
sheet1_tmp.budget = row15.budget ;
sheet1_tmp.revenue = row15.revenue ;
sheet1 = sheet1_tmp;

// # Output table : 'Page2'
Page2_tmp.Title = row15.Title ;
Page2_tmp.budget = row15.budget ;
Page2_tmp.revenue = row15.revenue ;
Page2_tmp.year = Var.year ;
Page2 = Page2_tmp;

// # Output table : 'page3'
page3_tmp.Title = row15.Title ;
page3_tmp.perte_ou_gain = Var.perte_ou_gain ;
page3_tmp.year = Var.year ;
page3 = page3_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "sheet1"
if(sheet1 != null) { 



	
	/**
	 * [tFileOutputExcel_2 main ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"sheet1"
						
						);
					}
					

								   				
	    				if(sheet1.ID != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_2 = 0;
					

					
						jxl.write.WritableCell cell_0_tFileOutputExcel_2 = new jxl.write.Number(columnIndex_tFileOutputExcel_2, startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,
					
//modif end
								sheet1.ID
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_0_tFileOutputExcel_2);
							int currentWith_0_tFileOutputExcel_2 = String.valueOf(((jxl.write.Number)cell_0_tFileOutputExcel_2).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_2=currentWith_0_tFileOutputExcel_2>10?10:currentWith_0_tFileOutputExcel_2;
							fitWidth_tFileOutputExcel_2[0]=fitWidth_tFileOutputExcel_2[0]>currentWith_0_tFileOutputExcel_2?fitWidth_tFileOutputExcel_2[0]:currentWith_0_tFileOutputExcel_2+2;
	    				} 
					
								   				
	    				if(sheet1.Title != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_2 = 1;
					

					
						jxl.write.WritableCell cell_1_tFileOutputExcel_2 = new jxl.write.Label(columnIndex_tFileOutputExcel_2, startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,
					
//modif end
								sheet1.Title
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_1_tFileOutputExcel_2);
							int currentWith_1_tFileOutputExcel_2 = cell_1_tFileOutputExcel_2.getContents().trim().length();
							fitWidth_tFileOutputExcel_2[1]=fitWidth_tFileOutputExcel_2[1]>currentWith_1_tFileOutputExcel_2?fitWidth_tFileOutputExcel_2[1]:currentWith_1_tFileOutputExcel_2+2;
	    				} 
					
								   				
	    				if(sheet1.Release != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_2 = 2;
					

					
						jxl.write.WritableCell cell_2_tFileOutputExcel_2 = new jxl.write.DateTime(columnIndex_tFileOutputExcel_2, startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,
					
//modif end
								sheet1.Release, cell_format_Release_tFileOutputExcel_2
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_2_tFileOutputExcel_2);
							int currentWith_2_tFileOutputExcel_2 = cell_2_tFileOutputExcel_2.getContents().trim().length();
							currentWith_2_tFileOutputExcel_2=12;
							fitWidth_tFileOutputExcel_2[2]=fitWidth_tFileOutputExcel_2[2]>currentWith_2_tFileOutputExcel_2?fitWidth_tFileOutputExcel_2[2]:currentWith_2_tFileOutputExcel_2+2;
	    				} 
					
								   				
	    				if(sheet1.budget != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_2 = 3;
					

					
						jxl.write.WritableCell cell_3_tFileOutputExcel_2 = new jxl.write.Number(columnIndex_tFileOutputExcel_2, startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,
					
//modif end
								sheet1.budget
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_3_tFileOutputExcel_2);
							int currentWith_3_tFileOutputExcel_2 = String.valueOf(((jxl.write.Number)cell_3_tFileOutputExcel_2).getValue()).trim().length();
							currentWith_3_tFileOutputExcel_2=currentWith_3_tFileOutputExcel_2>10?10:currentWith_3_tFileOutputExcel_2;
							fitWidth_tFileOutputExcel_2[3]=fitWidth_tFileOutputExcel_2[3]>currentWith_3_tFileOutputExcel_2?fitWidth_tFileOutputExcel_2[3]:currentWith_3_tFileOutputExcel_2+2;
	    				} 
					
								   				
	    				if(sheet1.revenue != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_2 = 4;
					

					
						jxl.write.WritableCell cell_4_tFileOutputExcel_2 = new jxl.write.Number(columnIndex_tFileOutputExcel_2, startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,
					
//modif end
								sheet1.revenue
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_4_tFileOutputExcel_2);
							int currentWith_4_tFileOutputExcel_2 = String.valueOf(((jxl.write.Number)cell_4_tFileOutputExcel_2).getValue()).trim().length();
							currentWith_4_tFileOutputExcel_2=currentWith_4_tFileOutputExcel_2>10?10:currentWith_4_tFileOutputExcel_2;
							fitWidth_tFileOutputExcel_2[4]=fitWidth_tFileOutputExcel_2[4]>currentWith_4_tFileOutputExcel_2?fitWidth_tFileOutputExcel_2[4]:currentWith_4_tFileOutputExcel_2+2;
	    				} 
					
    			nb_line_tFileOutputExcel_2++;
				
 


	tos_count_tFileOutputExcel_2++;

/**
 * [tFileOutputExcel_2 main ] stop
 */
	
	/**
	 * [tFileOutputExcel_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_2";

	

 



/**
 * [tFileOutputExcel_2 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputExcel_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_2";

	

 



/**
 * [tFileOutputExcel_2 process_data_end ] stop
 */

} // End of branch "sheet1"




// Start of branch "Page2"
if(Page2 != null) { 



	
	/**
	 * [tSortRow_2_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"Page2"
						
						);
					}
					



	ComparablePage2Struct arrayRowtSortRow_2_SortOut = new ComparablePage2Struct();

	arrayRowtSortRow_2_SortOut.Title = Page2.Title;
	arrayRowtSortRow_2_SortOut.budget = Page2.budget;
	arrayRowtSortRow_2_SortOut.revenue = Page2.revenue;
	arrayRowtSortRow_2_SortOut.year = Page2.year;	
	list_tSortRow_2_SortOut.add(arrayRowtSortRow_2_SortOut);

 


	tos_count_tSortRow_2_SortOut++;

/**
 * [tSortRow_2_SortOut main ] stop
 */
	
	/**
	 * [tSortRow_2_SortOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut process_data_begin ] stop
 */
	
	/**
	 * [tSortRow_2_SortOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut process_data_end ] stop
 */

} // End of branch "Page2"




// Start of branch "page3"
if(page3 != null) { 



	
	/**
	 * [tSortRow_3_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"page3"
						
						);
					}
					



	Comparablepage3Struct arrayRowtSortRow_3_SortOut = new Comparablepage3Struct();

	arrayRowtSortRow_3_SortOut.Title = page3.Title;
	arrayRowtSortRow_3_SortOut.perte_ou_gain = page3.perte_ou_gain;
	arrayRowtSortRow_3_SortOut.year = page3.year;	
	list_tSortRow_3_SortOut.add(arrayRowtSortRow_3_SortOut);

 


	tos_count_tSortRow_3_SortOut++;

/**
 * [tSortRow_3_SortOut main ] stop
 */
	
	/**
	 * [tSortRow_3_SortOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	

 



/**
 * [tSortRow_3_SortOut process_data_begin ] stop
 */
	
	/**
	 * [tSortRow_3_SortOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	

 



/**
 * [tSortRow_3_SortOut process_data_end ] stop
 */

} // End of branch "page3"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tFileOutputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 process_data_end ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn process_data_end ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	


}

globalMap.put("tSortRow_1_SortIn_NB_LINE",nb_line_tSortRow_1_SortIn);

 

ok_Hash.put("tSortRow_1_SortIn", true);
end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_1_SortIn end ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

		writeableWorkbook_tFileOutputExcel_1.write();
		writeableWorkbook_tFileOutputExcel_1.close();
		if(headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0){
			nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 -1;
		}
		globalMap.put("tFileOutputExcel_1_NB_LINE",nb_line_tFileOutputExcel_1);
		
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row10");
			  	}
			  	
 

ok_Hash.put("tFileOutputExcel_1", true);
end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());




/**
 * [tFileOutputExcel_1 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
					if(outtFileOutputDelimited_1!=null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}
				
				globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row13");
			  	}
			  	
 

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_1 end ] stop
 */




	
	/**
	 * [tFileOutputXML_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputXML_1";

	

	out_tFileOutputXML_1.write(footers_tFileOutputXML_1[0]);

	out_tFileOutputXML_1.newLine();
	out_tFileOutputXML_1.close();
globalMap.put("tFileOutputXML_1_NB_LINE",nb_line_tFileOutputXML_1);
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row14");
			  	}
			  	
 

ok_Hash.put("tFileOutputXML_1", true);
end_Hash.put("tFileOutputXML_1", System.currentTimeMillis());




/**
 * [tFileOutputXML_1 end ] stop
 */




	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row15");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFileOutputExcel_2 end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_2";

	

		writeableWorkbook_tFileOutputExcel_2.write();
		writeableWorkbook_tFileOutputExcel_2.close();
		if(headerIsInserted_tFileOutputExcel_2 && nb_line_tFileOutputExcel_2 > 0){
			nb_line_tFileOutputExcel_2 = nb_line_tFileOutputExcel_2 -1;
		}
		globalMap.put("tFileOutputExcel_2_NB_LINE",nb_line_tFileOutputExcel_2);
		
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"sheet1");
			  	}
			  	
 

ok_Hash.put("tFileOutputExcel_2", true);
end_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());




/**
 * [tFileOutputExcel_2 end ] stop
 */




	
	/**
	 * [tSortRow_2_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

Page2Struct[] array_tSortRow_2_SortOut = list_tSortRow_2_SortOut.toArray(new ComparablePage2Struct[0]);

java.util.Arrays.sort(array_tSortRow_2_SortOut);

globalMap.put("tSortRow_2",array_tSortRow_2_SortOut);


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"Page2");
			  	}
			  	
 

ok_Hash.put("tSortRow_2_SortOut", true);
end_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_2_SortOut end ] stop
 */


	
	/**
	 * [tAggregateRow_1_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGOUT", false);
		start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row17");
					}
				
		int tos_count_tAggregateRow_1_AGGOUT = 0;
		

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

	
	
		class AggCountDistinctValuesStruct_Title_tAggregateRow_1 { // G_OutBegin_AggR_1100
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
    					String Title;
    					int year;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.Title == null) ? 0 : this.Title.hashCode());
								
									result = prime * result + (int) this.year;
									
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final AggCountDistinctValuesStruct_Title_tAggregateRow_1 other = (AggCountDistinctValuesStruct_Title_tAggregateRow_1) obj;
				
									if (this.Title == null) {
										if (other.Title != null) 
											return false;
									} else if (!this.Title.equals(other.Title)) 
										return false;
								
									if (this.year != other.year) 
										return false;
								
				
				return true;
			}
	  
	        
		} // G_OutBegin_AggR_1100

	

	class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				int year;
         			Long budget_cummule_sum;java.util.Set<AggCountDistinctValuesStruct_Title_tAggregateRow_1> distinctValues_Nombre_de_films = new java.util.HashSet<AggCountDistinctValuesStruct_Title_tAggregateRow_1>();
           			
         			Long revenue_cumule_sum;
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
								result = prime * result + (int) this.year;
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;
			
							if (this.year != other.year) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
	AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
	java.util.Map<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1>();
	

 



/**
 * [tAggregateRow_1_AGGOUT begin ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortIn", false);
		start_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	
		int tos_count_tSortRow_2_SortIn = 0;
		


Page2Struct[] array_tSortRow_2_SortIn = (Page2Struct[]) globalMap.remove("tSortRow_2");

int nb_line_tSortRow_2_SortIn = 0;

Page2Struct current_tSortRow_2_SortIn = null;

for(int i_tSortRow_2_SortIn = 0; i_tSortRow_2_SortIn < array_tSortRow_2_SortIn.length; i_tSortRow_2_SortIn++){
	current_tSortRow_2_SortIn = array_tSortRow_2_SortIn[i_tSortRow_2_SortIn];
	row17.Title = current_tSortRow_2_SortIn.Title;
	row17.budget = current_tSortRow_2_SortIn.budget;
	row17.revenue = current_tSortRow_2_SortIn.revenue;
	row17.year = current_tSortRow_2_SortIn.year;
	// increase number of line sorted
	nb_line_tSortRow_2_SortIn++;

 



/**
 * [tSortRow_2_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 


	tos_count_tSortRow_2_SortIn++;

/**
 * [tSortRow_2_SortIn main ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn process_data_begin ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row17"
						
						);
					}
					
	
operation_finder_tAggregateRow_1.year = row17.year;
			

	operation_finder_tAggregateRow_1.hashCodeDirty = true;
	
	operation_result_tAggregateRow_1 = hash_tAggregateRow_1.get(operation_finder_tAggregateRow_1);

	

	if(operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

		operation_result_tAggregateRow_1.year = operation_finder_tAggregateRow_1.year;
				
		
		

		hash_tAggregateRow_1.put(operation_result_tAggregateRow_1, operation_result_tAggregateRow_1);
	
	} // G_OutMain_AggR_001


	
					if(operation_result_tAggregateRow_1.budget_cummule_sum == null) {
						operation_result_tAggregateRow_1.budget_cummule_sum = (long) 0;
					}
					
					if( row17.budget != null)
						operation_result_tAggregateRow_1.budget_cummule_sum += row17.budget;
				
				AggCountDistinctValuesStruct_Title_tAggregateRow_1 countDistinctValues_Nombre_de_films_tAggregateRow_1 = new AggCountDistinctValuesStruct_Title_tAggregateRow_1();
			
				countDistinctValues_Nombre_de_films_tAggregateRow_1.year = row17.year;
						
				countDistinctValues_Nombre_de_films_tAggregateRow_1.Title = row17.Title;
				operation_result_tAggregateRow_1.distinctValues_Nombre_de_films.add(countDistinctValues_Nombre_de_films_tAggregateRow_1);
				
					if(operation_result_tAggregateRow_1.revenue_cumule_sum == null) {
						operation_result_tAggregateRow_1.revenue_cumule_sum = (long) 0;
					}
					
					if( row17.revenue != null)
						operation_result_tAggregateRow_1.revenue_cumule_sum += row17.revenue;


 


	tos_count_tAggregateRow_1_AGGOUT++;

/**
 * [tAggregateRow_1_AGGOUT main ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGOUT process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT process_data_begin ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGOUT process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT process_data_end ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn process_data_end ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	


}

globalMap.put("tSortRow_2_SortIn_NB_LINE",nb_line_tSortRow_2_SortIn);

 

ok_Hash.put("tSortRow_2_SortIn", true);
end_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_2_SortIn end ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row17");
			  	}
			  	
 

ok_Hash.put("tAggregateRow_1_AGGOUT", true);
end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGOUT end ] stop
 */


	
	/**
	 * [tFileOutputExcel_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputExcel_3", false);
		start_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputExcel_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row18");
					}
				
		int tos_count_tFileOutputExcel_3 = 0;
		


		
		int columnIndex_tFileOutputExcel_3 = 0;
		boolean headerIsInserted_tFileOutputExcel_3 = false;
		
		
		int nb_line_tFileOutputExcel_3 = 0;

		String fileName_tFileOutputExcel_3="C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question6.xls";
		java.io.File file_tFileOutputExcel_3 = new java.io.File(fileName_tFileOutputExcel_3);
		boolean isFileGenerated_tFileOutputExcel_3 = true;
		if(file_tFileOutputExcel_3.exists()){
			isFileGenerated_tFileOutputExcel_3 = false;
		}
//create directory only if not exists
          java.io.File parentFile_tFileOutputExcel_3 = file_tFileOutputExcel_3.getParentFile();
          if (parentFile_tFileOutputExcel_3 != null && !parentFile_tFileOutputExcel_3.exists()) {
        	
             parentFile_tFileOutputExcel_3.mkdirs();
        	
          }

		jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_3 = null;
		jxl.write.WritableSheet writableSheet_tFileOutputExcel_3 = null;

		jxl.WorkbookSettings workbookSettings_tFileOutputExcel_3 = new jxl.WorkbookSettings();
        workbookSettings_tFileOutputExcel_3.setEncoding("ISO-8859-15");
        if (file_tFileOutputExcel_3.exists()) {
        jxl.Workbook workbook_tFileOutputExcel_3 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_3,workbookSettings_tFileOutputExcel_3);
        workbookSettings_tFileOutputExcel_3.setWriteAccess(null);
        writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
                	new java.io.BufferedOutputStream(new java.io.FileOutputStream(file_tFileOutputExcel_3, false)),
                	workbook_tFileOutputExcel_3,
                	true,
                    workbookSettings_tFileOutputExcel_3);
        }else{
		writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
            		new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_3)),
            		true,
            		workbookSettings_tFileOutputExcel_3);
        }

        writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheet("Sheet2");
        if(writableSheet_tFileOutputExcel_3 == null){
        	writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet2", writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
		}

        else {

            String[] sheetNames_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheetNames();
            for (int i = 0; i < sheetNames_tFileOutputExcel_3.length; i++) {
                if (sheetNames_tFileOutputExcel_3[i].equals("Sheet2")) {
                    writeableWorkbook_tFileOutputExcel_3.removeSheet(i);
                    break;
                }
            }

			writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet2", writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
        }

        //modif start
        int startRowNum_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3.getRows();
		//modif end

		int[] fitWidth_tFileOutputExcel_3 = new int[4];
		for(int i_tFileOutputExcel_3=0;i_tFileOutputExcel_3<4;i_tFileOutputExcel_3++){
		    int fitCellViewSize_tFileOutputExcel_3=writableSheet_tFileOutputExcel_3.getColumnView(i_tFileOutputExcel_3).getSize();
			fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3]=fitCellViewSize_tFileOutputExcel_3/256;
			if(fitCellViewSize_tFileOutputExcel_3%256!=0){
				fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3]+=1;
			}
		}

		jxl.write.WritableFont wf_tFileOutputExcel_3 = new jxl.write.WritableFont(jxl.write.WritableFont.TAHOMA, 10, jxl.write.WritableFont.NO_BOLD, false);
        jxl.write.WritableCellFormat format_tFileOutputExcel_3  = new jxl.write.WritableCellFormat(wf_tFileOutputExcel_3);



		if (startRowNum_tFileOutputExcel_3 == 0){
	//modif end
		//modif start
			writableSheet_tFileOutputExcel_3.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_3, "budget_cummule"
					,format_tFileOutputExcel_3
			));
		//modif end
		fitWidth_tFileOutputExcel_3[0]=fitWidth_tFileOutputExcel_3[0]>14?fitWidth_tFileOutputExcel_3[0]:14;
		//modif start
			writableSheet_tFileOutputExcel_3.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_3, "revenue_cumule"
					,format_tFileOutputExcel_3
			));
		//modif end
		fitWidth_tFileOutputExcel_3[1]=fitWidth_tFileOutputExcel_3[1]>14?fitWidth_tFileOutputExcel_3[1]:14;
		//modif start
			writableSheet_tFileOutputExcel_3.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_3, "year"
					,format_tFileOutputExcel_3
			));
		//modif end
		fitWidth_tFileOutputExcel_3[2]=fitWidth_tFileOutputExcel_3[2]>4?fitWidth_tFileOutputExcel_3[2]:4;
		//modif start
			writableSheet_tFileOutputExcel_3.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_3, "Nombre_de_films"
					,format_tFileOutputExcel_3
			));
		//modif end
		fitWidth_tFileOutputExcel_3[3]=fitWidth_tFileOutputExcel_3[3]>15?fitWidth_tFileOutputExcel_3[3]:15;
		nb_line_tFileOutputExcel_3 ++;
		headerIsInserted_tFileOutputExcel_3 = true;
	}


 



/**
 * [tFileOutputExcel_3 begin ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGIN", false);
		start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	
		int tos_count_tAggregateRow_1_AGGIN = 0;
		

java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1.values();

globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

for(AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600



 



/**
 * [tAggregateRow_1_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	
row18.budget_cummule = aggregated_row_tAggregateRow_1.budget_cummule_sum;
                                	row18.revenue_cumule = aggregated_row_tAggregateRow_1.revenue_cumule_sum;
                                	
            				    row18.year = aggregated_row_tAggregateRow_1.year;
            				    row18.Nombre_de_films = (long) aggregated_row_tAggregateRow_1.distinctValues_Nombre_de_films.size();
	                                	

 


	tos_count_tAggregateRow_1_AGGIN++;

/**
 * [tAggregateRow_1_AGGIN main ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputExcel_3 main ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row18"
						
						);
					}
					

								   				
	    				if(row18.budget_cummule != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_3 = 0;
					

					
						jxl.write.WritableCell cell_0_tFileOutputExcel_3 = new jxl.write.Number(columnIndex_tFileOutputExcel_3, startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,
					
//modif end
								row18.budget_cummule
						,format_tFileOutputExcel_3
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_3.addCell(cell_0_tFileOutputExcel_3);
							int currentWith_0_tFileOutputExcel_3 = String.valueOf(((jxl.write.Number)cell_0_tFileOutputExcel_3).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_3=currentWith_0_tFileOutputExcel_3>10?10:currentWith_0_tFileOutputExcel_3;
							fitWidth_tFileOutputExcel_3[0]=fitWidth_tFileOutputExcel_3[0]>currentWith_0_tFileOutputExcel_3?fitWidth_tFileOutputExcel_3[0]:currentWith_0_tFileOutputExcel_3+2;
	    				} 
					
								   				
	    				if(row18.revenue_cumule != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_3 = 1;
					

					
						jxl.write.WritableCell cell_1_tFileOutputExcel_3 = new jxl.write.Number(columnIndex_tFileOutputExcel_3, startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,
					
//modif end
								row18.revenue_cumule
						,format_tFileOutputExcel_3
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_3.addCell(cell_1_tFileOutputExcel_3);
							int currentWith_1_tFileOutputExcel_3 = String.valueOf(((jxl.write.Number)cell_1_tFileOutputExcel_3).getValue()).trim().length();
							currentWith_1_tFileOutputExcel_3=currentWith_1_tFileOutputExcel_3>10?10:currentWith_1_tFileOutputExcel_3;
							fitWidth_tFileOutputExcel_3[1]=fitWidth_tFileOutputExcel_3[1]>currentWith_1_tFileOutputExcel_3?fitWidth_tFileOutputExcel_3[1]:currentWith_1_tFileOutputExcel_3+2;
	    				} 
					
								
					
//modif start
					
						columnIndex_tFileOutputExcel_3 = 2;
					

					
						jxl.write.WritableCell cell_2_tFileOutputExcel_3 = new jxl.write.Number(columnIndex_tFileOutputExcel_3, startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,
					
//modif end
								row18.year
						,format_tFileOutputExcel_3
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_3.addCell(cell_2_tFileOutputExcel_3);
							int currentWith_2_tFileOutputExcel_3 = String.valueOf(((jxl.write.Number)cell_2_tFileOutputExcel_3).getValue()).trim().length();
							currentWith_2_tFileOutputExcel_3=currentWith_2_tFileOutputExcel_3>10?10:currentWith_2_tFileOutputExcel_3;
							fitWidth_tFileOutputExcel_3[2]=fitWidth_tFileOutputExcel_3[2]>currentWith_2_tFileOutputExcel_3?fitWidth_tFileOutputExcel_3[2]:currentWith_2_tFileOutputExcel_3+2;
								   				
	    				if(row18.Nombre_de_films != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_3 = 3;
					

					
						jxl.write.WritableCell cell_3_tFileOutputExcel_3 = new jxl.write.Number(columnIndex_tFileOutputExcel_3, startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,
					
//modif end
								row18.Nombre_de_films
						,format_tFileOutputExcel_3
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_3.addCell(cell_3_tFileOutputExcel_3);
							int currentWith_3_tFileOutputExcel_3 = String.valueOf(((jxl.write.Number)cell_3_tFileOutputExcel_3).getValue()).trim().length();
							currentWith_3_tFileOutputExcel_3=currentWith_3_tFileOutputExcel_3>10?10:currentWith_3_tFileOutputExcel_3;
							fitWidth_tFileOutputExcel_3[3]=fitWidth_tFileOutputExcel_3[3]>currentWith_3_tFileOutputExcel_3?fitWidth_tFileOutputExcel_3[3]:currentWith_3_tFileOutputExcel_3+2;
	    				} 
					
    			nb_line_tFileOutputExcel_3++;
				
 


	tos_count_tFileOutputExcel_3++;

/**
 * [tFileOutputExcel_3 main ] stop
 */
	
	/**
	 * [tFileOutputExcel_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_3";

	

 



/**
 * [tFileOutputExcel_3 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputExcel_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_3";

	

 



/**
 * [tFileOutputExcel_3 process_data_end ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN process_data_end ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

} // G_AggR_600

 

ok_Hash.put("tAggregateRow_1_AGGIN", true);
end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGIN end ] stop
 */

	
	/**
	 * [tFileOutputExcel_3 end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_3";

	

		writeableWorkbook_tFileOutputExcel_3.write();
		writeableWorkbook_tFileOutputExcel_3.close();
		if(headerIsInserted_tFileOutputExcel_3 && nb_line_tFileOutputExcel_3 > 0){
			nb_line_tFileOutputExcel_3 = nb_line_tFileOutputExcel_3 -1;
		}
		globalMap.put("tFileOutputExcel_3_NB_LINE",nb_line_tFileOutputExcel_3);
		
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row18");
			  	}
			  	
 

ok_Hash.put("tFileOutputExcel_3", true);
end_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());




/**
 * [tFileOutputExcel_3 end ] stop
 */
















	
	/**
	 * [tSortRow_3_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	

page3Struct[] array_tSortRow_3_SortOut = list_tSortRow_3_SortOut.toArray(new Comparablepage3Struct[0]);

java.util.Arrays.sort(array_tSortRow_3_SortOut);

globalMap.put("tSortRow_3",array_tSortRow_3_SortOut);


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"page3");
			  	}
			  	
 

ok_Hash.put("tSortRow_3_SortOut", true);
end_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_3_SortOut end ] stop
 */


	
	/**
	 * [tFileOutputExcel_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputExcel_4", false);
		start_Hash.put("tFileOutputExcel_4", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputExcel_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row19");
					}
				
		int tos_count_tFileOutputExcel_4 = 0;
		


		
		int columnIndex_tFileOutputExcel_4 = 0;
		boolean headerIsInserted_tFileOutputExcel_4 = false;
		
		
		int nb_line_tFileOutputExcel_4 = 0;

		String fileName_tFileOutputExcel_4="C:/Program Files (x86)/TOS_DI-8.0.1/studio/workspace/question6.xls";
		java.io.File file_tFileOutputExcel_4 = new java.io.File(fileName_tFileOutputExcel_4);
		boolean isFileGenerated_tFileOutputExcel_4 = true;
		if(file_tFileOutputExcel_4.exists()){
			isFileGenerated_tFileOutputExcel_4 = false;
		}
//create directory only if not exists
          java.io.File parentFile_tFileOutputExcel_4 = file_tFileOutputExcel_4.getParentFile();
          if (parentFile_tFileOutputExcel_4 != null && !parentFile_tFileOutputExcel_4.exists()) {
        	
             parentFile_tFileOutputExcel_4.mkdirs();
        	
          }

		jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_4 = null;
		jxl.write.WritableSheet writableSheet_tFileOutputExcel_4 = null;

		jxl.WorkbookSettings workbookSettings_tFileOutputExcel_4 = new jxl.WorkbookSettings();
        workbookSettings_tFileOutputExcel_4.setEncoding("ISO-8859-15");
        if (file_tFileOutputExcel_4.exists()) {
        jxl.Workbook workbook_tFileOutputExcel_4 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_4,workbookSettings_tFileOutputExcel_4);
        workbookSettings_tFileOutputExcel_4.setWriteAccess(null);
        writeableWorkbook_tFileOutputExcel_4 = new jxl.write.biff.WritableWorkbookImpl(
                	new java.io.BufferedOutputStream(new java.io.FileOutputStream(file_tFileOutputExcel_4, false)),
                	workbook_tFileOutputExcel_4,
                	true,
                    workbookSettings_tFileOutputExcel_4);
        }else{
		writeableWorkbook_tFileOutputExcel_4 = new jxl.write.biff.WritableWorkbookImpl(
            		new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_4)),
            		true,
            		workbookSettings_tFileOutputExcel_4);
        }

        writableSheet_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.getSheet("Sheet3");
        if(writableSheet_tFileOutputExcel_4 == null){
        	writableSheet_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.createSheet("Sheet3", writeableWorkbook_tFileOutputExcel_4.getNumberOfSheets());
		}

        else {

            String[] sheetNames_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.getSheetNames();
            for (int i = 0; i < sheetNames_tFileOutputExcel_4.length; i++) {
                if (sheetNames_tFileOutputExcel_4[i].equals("Sheet3")) {
                    writeableWorkbook_tFileOutputExcel_4.removeSheet(i);
                    break;
                }
            }

			writableSheet_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.createSheet("Sheet3", writeableWorkbook_tFileOutputExcel_4.getNumberOfSheets());
        }

        //modif start
        int startRowNum_tFileOutputExcel_4 = writableSheet_tFileOutputExcel_4.getRows();
		//modif end

		int[] fitWidth_tFileOutputExcel_4 = new int[3];
		for(int i_tFileOutputExcel_4=0;i_tFileOutputExcel_4<3;i_tFileOutputExcel_4++){
		    int fitCellViewSize_tFileOutputExcel_4=writableSheet_tFileOutputExcel_4.getColumnView(i_tFileOutputExcel_4).getSize();
			fitWidth_tFileOutputExcel_4[i_tFileOutputExcel_4]=fitCellViewSize_tFileOutputExcel_4/256;
			if(fitCellViewSize_tFileOutputExcel_4%256!=0){
				fitWidth_tFileOutputExcel_4[i_tFileOutputExcel_4]+=1;
			}
		}



		if (startRowNum_tFileOutputExcel_4 == 0){
	//modif end
		//modif start
			writableSheet_tFileOutputExcel_4.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_4, "Title"
			));
		//modif end
		fitWidth_tFileOutputExcel_4[0]=fitWidth_tFileOutputExcel_4[0]>5?fitWidth_tFileOutputExcel_4[0]:5;
		//modif start
			writableSheet_tFileOutputExcel_4.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_4, "perte_ou_gain"
			));
		//modif end
		fitWidth_tFileOutputExcel_4[1]=fitWidth_tFileOutputExcel_4[1]>13?fitWidth_tFileOutputExcel_4[1]:13;
		//modif start
			writableSheet_tFileOutputExcel_4.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_4, "year"
			));
		//modif end
		fitWidth_tFileOutputExcel_4[2]=fitWidth_tFileOutputExcel_4[2]>4?fitWidth_tFileOutputExcel_4[2]:4;
		nb_line_tFileOutputExcel_4 ++;
		headerIsInserted_tFileOutputExcel_4 = true;
	}


 



/**
 * [tFileOutputExcel_4 begin ] stop
 */



	
	/**
	 * [tSortRow_3_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_3_SortIn", false);
		start_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	
		int tos_count_tSortRow_3_SortIn = 0;
		


page3Struct[] array_tSortRow_3_SortIn = (page3Struct[]) globalMap.remove("tSortRow_3");

int nb_line_tSortRow_3_SortIn = 0;

page3Struct current_tSortRow_3_SortIn = null;

for(int i_tSortRow_3_SortIn = 0; i_tSortRow_3_SortIn < array_tSortRow_3_SortIn.length; i_tSortRow_3_SortIn++){
	current_tSortRow_3_SortIn = array_tSortRow_3_SortIn[i_tSortRow_3_SortIn];
	row19.Title = current_tSortRow_3_SortIn.Title;
	row19.perte_ou_gain = current_tSortRow_3_SortIn.perte_ou_gain;
	row19.year = current_tSortRow_3_SortIn.year;
	// increase number of line sorted
	nb_line_tSortRow_3_SortIn++;

 



/**
 * [tSortRow_3_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_3_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	

 


	tos_count_tSortRow_3_SortIn++;

/**
 * [tSortRow_3_SortIn main ] stop
 */
	
	/**
	 * [tSortRow_3_SortIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	

 



/**
 * [tSortRow_3_SortIn process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputExcel_4 main ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row19"
						
						);
					}
					

								   				
	    				if(row19.Title != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_4 = 0;
					

					
						jxl.write.WritableCell cell_0_tFileOutputExcel_4 = new jxl.write.Label(columnIndex_tFileOutputExcel_4, startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,
					
//modif end
								row19.Title
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_4.addCell(cell_0_tFileOutputExcel_4);
							int currentWith_0_tFileOutputExcel_4 = cell_0_tFileOutputExcel_4.getContents().trim().length();
							fitWidth_tFileOutputExcel_4[0]=fitWidth_tFileOutputExcel_4[0]>currentWith_0_tFileOutputExcel_4?fitWidth_tFileOutputExcel_4[0]:currentWith_0_tFileOutputExcel_4+2;
	    				} 
					
								
					
//modif start
					
						columnIndex_tFileOutputExcel_4 = 1;
					

					
						jxl.write.WritableCell cell_1_tFileOutputExcel_4 = new jxl.write.Number(columnIndex_tFileOutputExcel_4, startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,
					
//modif end
								row19.perte_ou_gain
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_4.addCell(cell_1_tFileOutputExcel_4);
							int currentWith_1_tFileOutputExcel_4 = String.valueOf(((jxl.write.Number)cell_1_tFileOutputExcel_4).getValue()).trim().length();
							currentWith_1_tFileOutputExcel_4=currentWith_1_tFileOutputExcel_4>10?10:currentWith_1_tFileOutputExcel_4;
							fitWidth_tFileOutputExcel_4[1]=fitWidth_tFileOutputExcel_4[1]>currentWith_1_tFileOutputExcel_4?fitWidth_tFileOutputExcel_4[1]:currentWith_1_tFileOutputExcel_4+2;
								
					
//modif start
					
						columnIndex_tFileOutputExcel_4 = 2;
					

					
						jxl.write.WritableCell cell_2_tFileOutputExcel_4 = new jxl.write.Number(columnIndex_tFileOutputExcel_4, startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,
					
//modif end
								row19.year
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_4.addCell(cell_2_tFileOutputExcel_4);
							int currentWith_2_tFileOutputExcel_4 = String.valueOf(((jxl.write.Number)cell_2_tFileOutputExcel_4).getValue()).trim().length();
							currentWith_2_tFileOutputExcel_4=currentWith_2_tFileOutputExcel_4>10?10:currentWith_2_tFileOutputExcel_4;
							fitWidth_tFileOutputExcel_4[2]=fitWidth_tFileOutputExcel_4[2]>currentWith_2_tFileOutputExcel_4?fitWidth_tFileOutputExcel_4[2]:currentWith_2_tFileOutputExcel_4+2;
    			nb_line_tFileOutputExcel_4++;
				
 


	tos_count_tFileOutputExcel_4++;

/**
 * [tFileOutputExcel_4 main ] stop
 */
	
	/**
	 * [tFileOutputExcel_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_4";

	

 



/**
 * [tFileOutputExcel_4 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputExcel_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_4";

	

 



/**
 * [tFileOutputExcel_4 process_data_end ] stop
 */



	
	/**
	 * [tSortRow_3_SortIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	

 



/**
 * [tSortRow_3_SortIn process_data_end ] stop
 */
	
	/**
	 * [tSortRow_3_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	


}

globalMap.put("tSortRow_3_SortIn_NB_LINE",nb_line_tSortRow_3_SortIn);

 

ok_Hash.put("tSortRow_3_SortIn", true);
end_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_3_SortIn end ] stop
 */

	
	/**
	 * [tFileOutputExcel_4 end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_4";

	

		writeableWorkbook_tFileOutputExcel_4.write();
		writeableWorkbook_tFileOutputExcel_4.close();
		if(headerIsInserted_tFileOutputExcel_4 && nb_line_tFileOutputExcel_4 > 0){
			nb_line_tFileOutputExcel_4 = nb_line_tFileOutputExcel_4 -1;
		}
		globalMap.put("tFileOutputExcel_4_NB_LINE",nb_line_tFileOutputExcel_4);
		
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row19");
			  	}
			  	
 

ok_Hash.put("tFileOutputExcel_4", true);
end_Hash.put("tFileOutputExcel_4", System.currentTimeMillis());




/**
 * [tFileOutputExcel_4 end ] stop
 */































	
	/**
	 * [tFileOutputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	



		
			
					if(outtFileOutputDelimited_2!=null) {
						outtFileOutputDelimited_2.flush();
						outtFileOutputDelimited_2.close();
					}
				
				globalMap.put("tFileOutputDelimited_2_NB_LINE",nb_line_tFileOutputDelimited_2);
				globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_2", true);
	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row16");
			  	}
			  	
 

ok_Hash.put("tFileOutputDelimited_2", true);
end_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_2 end ] stop
 */















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tSortRow_3_SortIn"
							globalMap.remove("tSortRow_3");
						
							//free memory for "tAggregateRow_1_AGGIN"
							globalMap.remove("tAggregateRow_1");
						
							//free memory for "tSortRow_2_SortIn"
							globalMap.remove("tSortRow_2");
						
							//free memory for "tSortRow_1_SortIn"
							globalMap.remove("tSortRow_1");
						
					     			//free memory for "tMap_2"
					     			globalMap.remove("tHash_Lookup_row8"); 
				     			
					     			//free memory for "tMap_2"
					     			globalMap.remove("tHash_Lookup_row11"); 
				     			
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tLogRow_6 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 finally ] stop
 */

	
	/**
	 * [tFilterColumns_1 finally ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

 



/**
 * [tFilterColumns_1 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_2 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 finally ] stop
 */

	
	/**
	 * [tLogRow_5 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tLogRow_4 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	

 



/**
 * [tLogRow_4 finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn finally ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_1");
						if(outtFileOutputDelimited_1!=null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */




	
	/**
	 * [tFileOutputXML_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputXML_1";

	
	

 



/**
 * [tFileOutputXML_1 finally ] stop
 */




	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFileOutputExcel_2 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_2";

	

 



/**
 * [tFileOutputExcel_2 finally ] stop
 */




	
	/**
	 * [tSortRow_2_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_2_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN finally ] stop
 */

	
	/**
	 * [tFileOutputExcel_3 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_3";

	

 



/**
 * [tFileOutputExcel_3 finally ] stop
 */
















	
	/**
	 * [tSortRow_3_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortOut";

	

 



/**
 * [tSortRow_3_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_3_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_3";
	
	currentComponent="tSortRow_3_SortIn";

	

 



/**
 * [tSortRow_3_SortIn finally ] stop
 */

	
	/**
	 * [tFileOutputExcel_4 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_4";

	

 



/**
 * [tFileOutputExcel_4 finally ] stop
 */































	
	/**
	 * [tFileOutputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	


		if(resourceMap.get("finish_tFileOutputDelimited_2") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_2 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_2");
						if(outtFileOutputDelimited_2!=null) {
							outtFileOutputDelimited_2.flush();
							outtFileOutputDelimited_2.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_2 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableComparableLookupRow<row8Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer movie_id;

				public Integer getMovie_id () {
					return this.movie_id;
				}
				
			    public Long budget;

				public Long getBudget () {
					return this.budget;
				}
				
			    public Long revenue;

				public Long getRevenue () {
					return this.revenue;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.movie_id == null) ? 0 : this.movie_id.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.movie_id == null) {
							if (other.movie_id != null)
								return false;
						
						} else if (!this.movie_id.equals(other.movie_id))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.movie_id = this.movie_id;
	            other.budget = this.budget;
	            other.revenue = this.revenue;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.movie_id = this.movie_id;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.movie_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
						this.movie_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.movie_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.movie_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.budget = null;
           				} else {
           			    	this.budget = objectIn.readLong();
           				}
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.revenue = null;
           				} else {
           			    	this.revenue = objectIn.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						if(this.budget == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.budget);
		            	}
					
						if(this.revenue == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.revenue);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						if(this.budget == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeLong(this.budget);
		            	}
					
						if(this.revenue == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeLong(this.revenue);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("movie_id="+String.valueOf(movie_id));
		sb.append(",budget="+String.valueOf(budget));
		sb.append(",revenue="+String.valueOf(revenue));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.movie_id, other.movie_id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tAdvancedHash_row8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row8", false);
		start_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tAdvancedHash_row8 = 0;
		

			   		// connection name:row8
			   		// source node:tFileInputDelimited_1 - inputs:(after_tFileInputExcel_1) outputs:(row8,row8) | target node:tAdvancedHash_row8 - inputs:(row8) outputs:()
			   		// linked node: tMap_2 - inputs:(row3,row8,row11) outputs:(moviesOutput)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row8 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row8Struct>getLookup(matchingModeEnum_row8);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row8 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = "C:/Users/GLC/Downloads/moviesIncome.csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited("C:/Users/GLC/Downloads/moviesIncome.csv", "US-ASCII",";","\n",false,1,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row8 = null;			
									
			    						row8 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row8 = new row8Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row8.movie_id = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"movie_id", "row8", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row8.movie_id = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row8.budget = ParserUtils.parseTo_Long(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"budget", "row8", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row8.budget = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 2;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row8.revenue = ParserUtils.parseTo_Long(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"revenue", "row8", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row8.revenue = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row8 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tAdvancedHash_row8 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					


			   
			   

					row8Struct row8_HashRow = new row8Struct();
		   	   	   
				
				row8_HashRow.movie_id = row8.movie_id;
				
				row8_HashRow.budget = row8.budget;
				
				row8_HashRow.revenue = row8.revenue;
				
			tHash_Lookup_row8.put(row8_HashRow);
			
            




 


	tos_count_tAdvancedHash_row8++;

/**
 * [tAdvancedHash_row8 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)("C:/Users/GLC/Downloads/moviesIncome.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

tHash_Lookup_row8.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row8", true);
end_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());




/**
 * [tAdvancedHash_row8 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableComparableLookupRow<row11Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_TP_Talend = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String title1;

				public String getTitle1 () {
					return this.title1;
				}
				
			    public Float popularity1;

				public Float getPopularity1 () {
					return this.popularity1;
				}
				
			    public Float vote_average1;

				public Float getVote_average1 () {
					return this.vote_average1;
				}
				
			    public Integer vote_count1;

				public Integer getVote_count1 () {
					return this.vote_count1;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.title1 == null) ? 0 : this.title1.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row11Struct other = (row11Struct) obj;
		
						if (this.title1 == null) {
							if (other.title1 != null)
								return false;
						
						} else if (!this.title1.equals(other.title1))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row11Struct other) {

		other.title1 = this.title1;
	            other.popularity1 = this.popularity1;
	            other.vote_average1 = this.vote_average1;
	            other.vote_count1 = this.vote_count1;
	            
	}

	public void copyKeysDataTo(row11Struct other) {

		other.title1 = this.title1;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_TP_Talend.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_TP_Talend.length == 0) {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_TP_Talend = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_TP_Talend, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		Integer intReturn;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = unmarshaller.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, DataOutputStream dos,org.jboss.marshalling.Marshaller marshaller ) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.title1 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_TP_Talend) {

        	try {

        		int length = 0;
		
					this.title1 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.title1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.title1,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = dis.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.popularity1 = null;
           				} else {
           			    	this.popularity1 = objectIn.readFloat();
           				}
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.vote_average1 = null;
           				} else {
           			    	this.vote_average1 = objectIn.readFloat();
           				}
					
						this.vote_count1 = readInteger(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						if(this.popularity1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.popularity1);
		            	}
					
						if(this.vote_average1 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.vote_average1);
		            	}
					
					writeInteger(this.vote_count1, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						if(this.popularity1 == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeFloat(this.popularity1);
		            	}
					
						if(this.vote_average1 == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeFloat(this.vote_average1);
		            	}
					
					writeInteger(this.vote_count1, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("title1="+title1);
		sb.append(",popularity1="+String.valueOf(popularity1));
		sb.append(",vote_average1="+String.valueOf(vote_average1));
		sb.append(",vote_count1="+String.valueOf(vote_count1));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.title1, other.title1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputXML_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tAdvancedHash_row11 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row11", false);
		start_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row11";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row11");
					}
				
		int tos_count_tAdvancedHash_row11 = 0;
		

			   		// connection name:row11
			   		// source node:tFileInputXML_1 - inputs:(after_tFileInputExcel_1) outputs:(row11,row11) | target node:tAdvancedHash_row11 - inputs:(row11) outputs:()
			   		// linked node: tMap_2 - inputs:(row3,row8,row11) outputs:(moviesOutput)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row11 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row11Struct>getLookup(matchingModeEnum_row11);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row11", tHash_Lookup_row11);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row11 begin ] stop
 */



	
	/**
	 * [tFileInputXML_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputXML_1", false);
		start_Hash.put("tFileInputXML_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputXML_1";

	
		int tos_count_tFileInputXML_1 = 0;
		

	

int nb_line_tFileInputXML_1 = 0;

	String os_tFileInputXML_1 = System.getProperty("os.name").toLowerCase();
	boolean isWindows_tFileInputXML_1=false;
	if(os_tFileInputXML_1.indexOf("windows") > -1 || os_tFileInputXML_1.indexOf("nt") > -1){
		isWindows_tFileInputXML_1=true;
	}
class NameSpaceTool_tFileInputXML_1 {

    public java.util.HashMap<String, String> xmlNameSpaceMap = new java.util.HashMap<String, String>();
    
	private java.util.List<String> defualtNSPath = new java.util.ArrayList<String>();

    public void countNSMap(org.dom4j.Element el) {
        for (org.dom4j.Namespace ns : (java.util.List<org.dom4j.Namespace>) el.declaredNamespaces()) {
            if (ns.getPrefix().trim().length() == 0) {
                xmlNameSpaceMap.put("pre"+defualtNSPath.size(), ns.getURI());
                String path = "";
                org.dom4j.Element elTmp = el;
                while (elTmp != null) {
                	if (elTmp.getNamespacePrefix() != null && elTmp.getNamespacePrefix().length() > 0) {
                        path = "/" + elTmp.getNamespacePrefix() + ":" + elTmp.getName() + path;
                    } else {
                        path = "/" + elTmp.getName() + path;
                    }
                    elTmp = elTmp.getParent();
                }
                defualtNSPath.add(path);
            } else {
                xmlNameSpaceMap.put(ns.getPrefix(), ns.getURI());
            }

        }
        for (org.dom4j.Element e : (java.util.List<org.dom4j.Element>) el.elements()) {
            countNSMap(e);
        }
    }
    
    private final org.talend.xpath.XPathUtil util = new  org.talend.xpath.XPathUtil();
    
    {
    	util.setDefaultNSPath(defualtNSPath);
    }
    
	public String addDefaultNSPrefix(String path) {
		return util.addDefaultNSPrefix(path);
	}
	
	public String addDefaultNSPrefix(String relativeXpression, String basePath) {
		return util.addDefaultNSPrefix(relativeXpression,basePath);
	}
    
}

class XML_API_tFileInputXML_1{
	public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null && node instanceof org.dom4j.Element) {
        	org.dom4j.Attribute attri = ((org.dom4j.Element)node).attribute("nil");
        	if(attri != null && ("true").equals(attri.getText())){
            	return true;
            }
        }
        return false;
    }

    public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        return node == null ? true : false;
    }

    public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null) {
            return node.getText().length() == 0;
        }
        return false;
    }
}


org.dom4j.io.SAXReader reader_tFileInputXML_1 = new org.dom4j.io.SAXReader();
Object filename_tFileInputXML_1 = null;
try {
	filename_tFileInputXML_1 = "C:/Users/GLC/Downloads/moviesRatings.xml";
} catch(java.lang.Exception e) {
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
	
	
	System.err.println(e.getMessage());
	
}
if(filename_tFileInputXML_1 != null && filename_tFileInputXML_1 instanceof String && filename_tFileInputXML_1.toString().startsWith("//")){
	if (!isWindows_tFileInputXML_1){
		filename_tFileInputXML_1 = filename_tFileInputXML_1.toString().replaceFirst("//","/");
	}
}

boolean isValidFile_tFileInputXML_1 = true;
org.dom4j.Document doc_tFileInputXML_1 = null;
java.io.Closeable toClose_tFileInputXML_1 = null;
try{
	if(filename_tFileInputXML_1 instanceof java.io.InputStream){
		java.io.InputStream inputStream_tFileInputXML_1 = (java.io.InputStream)filename_tFileInputXML_1;
		toClose_tFileInputXML_1 = inputStream_tFileInputXML_1;
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(inputStream_tFileInputXML_1);
	}else{
		java.io.Reader unicodeReader_tFileInputXML_1 = new UnicodeReader(new java.io.FileInputStream(String.valueOf(filename_tFileInputXML_1)),"ISO-8859-15");
		toClose_tFileInputXML_1 = unicodeReader_tFileInputXML_1;
		org.xml.sax.InputSource in_tFileInputXML_1= new org.xml.sax.InputSource(unicodeReader_tFileInputXML_1);
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(in_tFileInputXML_1);
	}
}catch(java.lang.Exception e){
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
	
	System.err.println(e.getMessage());
	isValidFile_tFileInputXML_1 = false;
} finally {
	if(toClose_tFileInputXML_1!=null) {
		toClose_tFileInputXML_1.close();
	}
}
if(isValidFile_tFileInputXML_1){
NameSpaceTool_tFileInputXML_1 nsTool_tFileInputXML_1 = new NameSpaceTool_tFileInputXML_1();
nsTool_tFileInputXML_1.countNSMap(doc_tFileInputXML_1.getRootElement());
java.util.HashMap<String,String> xmlNameSpaceMap_tFileInputXML_1 = nsTool_tFileInputXML_1.xmlNameSpaceMap;  

org.dom4j.XPath x_tFileInputXML_1 = doc_tFileInputXML_1.createXPath(nsTool_tFileInputXML_1.addDefaultNSPrefix("/movies/movie"));  
x_tFileInputXML_1.setNamespaceURIs(xmlNameSpaceMap_tFileInputXML_1); 

java.util.List<org.dom4j.Node> nodeList_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)x_tFileInputXML_1.selectNodes(doc_tFileInputXML_1);	
XML_API_tFileInputXML_1 xml_api_tFileInputXML_1 = new XML_API_tFileInputXML_1();
String str_tFileInputXML_1 = "";
org.dom4j.Node node_tFileInputXML_1 = null;

//init all mapping xpaths
java.util.Map<Integer,org.dom4j.XPath> xpaths_tFileInputXML_1=new java.util.HashMap<Integer,org.dom4j.XPath>();
	class XPathUtil_tFileInputXML_1{
	
			   public void initXPaths_0(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			       java.util.HashMap<String,String> xmlNameSpaceMap){
			
	org.dom4j.XPath xpath_0 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("@title","/movies/movie"));
	xpath_0.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(0,xpath_0);
			
	org.dom4j.XPath xpath_1 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("@popularity","/movies/movie"));
	xpath_1.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(1,xpath_1);
			
	org.dom4j.XPath xpath_2 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("@vote_average","/movies/movie"));
	xpath_2.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(2,xpath_2);
			
	org.dom4j.XPath xpath_3 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("@vote_count","/movies/movie"));
	xpath_3.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(3,xpath_3);
			
	     }
	   
	      public void initXPaths(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			    java.util.HashMap<String,String> xmlNameSpaceMap){
			    
			        initXPaths_0(xpaths,nsTool, xmlNameSpaceMap);
			    
		   }
	}
	XPathUtil_tFileInputXML_1 xPathUtil_tFileInputXML_1 = new XPathUtil_tFileInputXML_1();
	xPathUtil_tFileInputXML_1.initXPaths(xpaths_tFileInputXML_1, nsTool_tFileInputXML_1, xmlNameSpaceMap_tFileInputXML_1);
for (org.dom4j.Node temp_tFileInputXML_1: nodeList_tFileInputXML_1) {
	if (nb_line_tFileInputXML_1>=4803) {
	
		break;
	}
		nb_line_tFileInputXML_1++;
		
	row11 = null;			
	row11 = null;			
	boolean whetherReject_tFileInputXML_1 = false;
	row11 = new row11Struct();
	try{
    Object obj0_tFileInputXML_1 = xpaths_tFileInputXML_1.get(0).evaluate(temp_tFileInputXML_1);
    if(obj0_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj0_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj0_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj0_tFileInputXML_1 instanceof String || obj0_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj0_tFileInputXML_1);
    } else if(obj0_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj0_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
									if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row11.title1 =null;
									}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
										row11.title1 ="";
									}else if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1 )){ 
										row11.title1 =null;
									}else{
		row11.title1 = str_tFileInputXML_1;
	}
    Object obj1_tFileInputXML_1 = xpaths_tFileInputXML_1.get(1).evaluate(temp_tFileInputXML_1);
    if(obj1_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj1_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj1_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj1_tFileInputXML_1 instanceof String || obj1_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj1_tFileInputXML_1);
    } else if(obj1_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj1_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}	
										if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row11.popularity1 =null;
										}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1) || xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)){
											row11.popularity1=null;
										}else{
		row11.popularity1 = ParserUtils.parseTo_Float(str_tFileInputXML_1);
	}
    Object obj2_tFileInputXML_1 = xpaths_tFileInputXML_1.get(2).evaluate(temp_tFileInputXML_1);
    if(obj2_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj2_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj2_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj2_tFileInputXML_1 instanceof String || obj2_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj2_tFileInputXML_1);
    } else if(obj2_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj2_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}	
										if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row11.vote_average1 =null;
										}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1) || xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)){
											row11.vote_average1=null;
										}else{
		row11.vote_average1 = ParserUtils.parseTo_Float(str_tFileInputXML_1);
	}
    Object obj3_tFileInputXML_1 = xpaths_tFileInputXML_1.get(3).evaluate(temp_tFileInputXML_1);
    if(obj3_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj3_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj3_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj3_tFileInputXML_1 instanceof String || obj3_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj3_tFileInputXML_1);
    } else if(obj3_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj3_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}	
										if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row11.vote_count1 =null;
										}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1) || xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)){
											row11.vote_count1=null;
										}else{
		row11.vote_count1 = ParserUtils.parseTo_Integer(str_tFileInputXML_1);
	} 
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputXML_1 = true;
                System.err.println(e.getMessage());
                row11 = null;
    }
			
			

 



/**
 * [tFileInputXML_1 begin ] stop
 */
	
	/**
	 * [tFileInputXML_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 


	tos_count_tFileInputXML_1++;

/**
 * [tFileInputXML_1 main ] stop
 */
	
	/**
	 * [tFileInputXML_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_begin ] stop
 */
// Start of branch "row11"
if(row11 != null) { 



	
	/**
	 * [tAdvancedHash_row11 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row11"
						
						);
					}
					


			   
			   

					row11Struct row11_HashRow = new row11Struct();
		   	   	   
				
				row11_HashRow.title1 = row11.title1;
				
				row11_HashRow.popularity1 = row11.popularity1;
				
				row11_HashRow.vote_average1 = row11.vote_average1;
				
				row11_HashRow.vote_count1 = row11.vote_count1;
				
			tHash_Lookup_row11.put(row11_HashRow);
			
            




 


	tos_count_tAdvancedHash_row11++;

/**
 * [tAdvancedHash_row11 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 process_data_end ] stop
 */

} // End of branch "row11"




	
	/**
	 * [tFileInputXML_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputXML_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	


}
	}
	globalMap.put("tFileInputXML_1_NB_LINE",nb_line_tFileInputXML_1);

	

 

ok_Hash.put("tFileInputXML_1", true);
end_Hash.put("tFileInputXML_1", System.currentTimeMillis());




/**
 * [tFileInputXML_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

tHash_Lookup_row11.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row11");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row11", true);
end_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());




/**
 * [tAdvancedHash_row11 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputXML_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final TP_Talend TP_TalendClass = new TP_Talend();

        int exitCode = TP_TalendClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = TP_Talend.class.getClassLoader().getResourceAsStream("local_project/tp_talend_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = TP_Talend.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob





this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputExcel_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputExcel_1) {
globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

e_tFileInputExcel_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : TP_Talend");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     479427 characters generated by Talend Open Studio for Data Integration 
 *     on the 15 octobre 2023 à 23:11:31 CEST
 ************************************************************************************************/