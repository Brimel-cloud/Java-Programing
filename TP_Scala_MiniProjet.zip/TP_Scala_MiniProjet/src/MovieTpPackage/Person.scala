package MovieTpPackage

// Person.scala
trait Person extends Comparable[Person] {
  def firstName: String
  def lastName: String
  def movies: List[Movie]
  def averageRating: Double
}

