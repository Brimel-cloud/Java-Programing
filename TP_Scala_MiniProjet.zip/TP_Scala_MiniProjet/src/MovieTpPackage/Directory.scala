package MovieTpPackage

// Directory.scala
class Directory(val directors: List[Director], val actors: List[Actor]) {
  // Méthode pour ajouter un réalisateur à la liste de réalisateurs
  def addDirector(director: Director): Directory = {
    new Directory(director :: directors, actors)
  }

  // Méthode pour supprimer un réalisateur de la liste de réalisateurs
  def removeDirector(director: Director): Directory = {
    new Directory(directors.filterNot(_ == director), actors)
  }

  // Méthode pour rechercher un réalisateur par nom
  def findDirectorByName(firstName: String, lastName: String): Option[Director] = {
    directors.find(director => director.firstName == firstName && director.lastName == lastName)
  }

  // Méthode pour ajouter un acteur à la liste d'acteurs
  def addActor(actor: Actor): Directory = {
    new Directory(directors, actor :: actors)
  }

  // Méthode pour supprimer un acteur de la liste d'acteurs
  def removeActor(actor: Actor): Directory = {
    new Directory(directors, actors.filterNot(_ == actor))
  }

  // Méthode pour rechercher un acteur par nom
  def findActorByName(firstName: String, lastName: String): Option[Actor] = {
    actors.find(actor => actor.firstName == firstName && actor.lastName == lastName)
  }
}


object Directory {
  def apply(directors: List[Director], actors: List[Actor]): Directory = new Directory(directors, actors)
}

