package MovieTpPackage

// Cinema.scala
class Cinema(val movies: List[Movie]) {
  def searchByRating(minRating: Double): List[Movie] = {
    movies.filter(_.rating >= minRating)
  }

  def searchByTitle(title: String): List[Movie] = {
    movies.filter(_.title.contains(title))
  }

  def searchByDirector(director: Director): List[Movie] = {
    movies.filter(_.director == director)
  }

  // Méthode pour obtenir les 20 réalisateurs avec la meilleure moyenne de leurs films
  def topDirectors(numDirectors: Int): List[Director] = {
    val allDirectors = movies.map(_.director) // Obtenez tous les réalisateurs
    val distinctDirectors = allDirectors.distinct // Supprimez les doublons
    val sortedDirectors = distinctDirectors.sortBy(_.averageRating)(Ordering[Double].reverse) // Triez par la moyenne des notes en ordre décroissant
    sortedDirectors.take(numDirectors) // Prenez les premiers réalisateurs
  }

  // Dans la classe Cinema
  def recentMovies(year: Int): List[Movie] = {
    movies.filter(_.year >= year)
  }

  // Dans la classe Cinema
  def highRatedMovies(minRating: Double): List[Movie] = {
    movies.filter(_.rating >= minRating)
  }

  // Dans la classe Cinema
  def customCriteriaMovies(minDuration: Int): List[Movie] = {
    movies.filter(_.runtime >= minDuration)
  }

  // Méthode pour ajouter un film à la collection
  def addMovie(movie: Movie): Cinema = {
    new Cinema(movie :: movies)
  }

  // Méthode pour supprimer un film de la collection
  def removeMovie(movie: Movie): Cinema = {
    new Cinema(movies.filterNot(_ == movie))
  }

  // Méthode pour rechercher des films par genre
  def findMoviesByGenre(genre: String): List[Movie] = {
    movies.filter(_.genre == genre)
  }

  // Méthode pour rechercher des films par année de sortie
  def findMoviesByYear(year: Int): List[Movie] = {
    movies.filter(_.year == year)
  }

  // Méthode pour obtenir une cinémathèque de films récents (sortis en 2015 et après)
  def recentMovies: Cinema = {
    val recentMoviesList = movies.filter(_.year >= 2015)
    new Cinema(recentMoviesList)
  }

  // Méthode pour obtenir une cinémathèque de films avec une note supérieure à 8
  def highRatedMovies: Cinema = {
    val highRatedMoviesList = movies.filter(_.rating > 8.0)
    new Cinema(highRatedMoviesList)
  }

  // Méthode pour obtenir une cinémathèque de films par genre (critère personnalisé)
  def moviesByGenre(genre: String): Cinema = {
    val filteredMovies = movies.filter(_.genre.equalsIgnoreCase(genre))
    new Cinema(filteredMovies)
  }

}

object Cinema {
  def apply(movies: List[Movie], directors: List[Director]): Cinema = {
    new Cinema(movies)
  }
}
