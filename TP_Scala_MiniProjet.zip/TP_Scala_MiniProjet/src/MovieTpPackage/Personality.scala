package MovieTpPackage

// Personality.scala
trait Personality {
  // Propriété pour le rating moyen
  def averageRating: Double
}
