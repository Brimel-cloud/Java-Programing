package MovieTpPackage

//<>
trait Comparable[T] {
  def compareTo(other: T): Int
}

