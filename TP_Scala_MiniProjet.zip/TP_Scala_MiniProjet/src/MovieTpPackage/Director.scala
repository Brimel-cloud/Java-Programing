package MovieTpPackage



// Director.scala
class Director(
                val firstName: String,
                val lastName: String,
                var movies: List[Movie]
              ) extends Person with Personality {

  def compareTo(other: Person): Int = {
    // Comparaison basée sur la moyenne des notes des films
    this.averageRating.compareTo(other.averageRating)
  }

  override def toString: String = {
    s"$firstName $lastName - Average Rating: $averageRating"
  }

  // Méthode pour calculer la moyenne des notes des films réalisés par le directeur
  def averageRating: Double = {
    if (movies.isEmpty) 0.0
    else {
      val totalRating = movies.map(_.rating).sum
      totalRating / movies.length
    }
  }
}

object Director {
  def apply(firstName: String, lastName: String, movies: List[Movie]): Director = {
    new Director(firstName, lastName, movies)
  }
}