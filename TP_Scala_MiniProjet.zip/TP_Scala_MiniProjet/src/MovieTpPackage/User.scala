package MovieTpPackage

class User(val name: String, val cinema1: Cinema, val cinema2: Cinema) {
  private var borrowedMovies: Map[Movie, Int] = Map.empty // Map de films empruntés avec le nombre d'exemplaires

  def borrowMovie(movie: Movie): Unit = {
    // Vérifiez si l'utilisateur peut emprunter plus de films (vous pouvez ajouter une limite)
    // Ajoutez le film à la liste des films empruntés
    // Si le film est déjà dans la liste, augmentez le nombre d'exemplaires
    borrowedMovies += (movie -> (borrowedMovies.getOrElse(movie, 0) + 1))
  }

  def returnMovie(movie: Movie): Unit = {
    // Retournez un exemplaire du film (réduisez le nombre d'exemplaires)
    borrowedMovies.get(movie) match {
      case Some(count) if count > 1 => borrowedMovies += (movie -> (count - 1))
      case Some(_) => borrowedMovies -= movie
      case _ => // Le film n'a pas été emprunté
    }
  }

  def searchMoviesByTitle(title: String): List[Movie] = {
    // Recherchez des films par titre dans les cinémathèques de l'utilisateur
    (cinema1.searchByTitle(title) ++ cinema2.searchByTitle(title)).distinct
  }

  def searchMoviesByDirector(director: Director): List[Movie] = {
    // Recherchez des films par réalisateur dans les cinémathèques de l'utilisateur
    (cinema1.searchByDirector(director) ++ cinema2.searchByDirector(director)).distinct
  }

  def getBorrowedMovies: Map[Movie, Int] = borrowedMovies
}

