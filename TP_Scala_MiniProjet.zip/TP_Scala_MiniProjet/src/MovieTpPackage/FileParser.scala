package MovieTpPackage


import MovieTpPackage.{Movie, Actor, Director} // Importez les classes du package MovieTpPackage

import scala.io.Source

class FileParser {


}
object FileParser {

  // Méthode pour lire le fichier CSV et créer les instances de films, acteurs et réalisateurs
  def parseCSV(filePath: String): (List[Movie], List[Actor], List[Director]) = {
    val lines = Source.fromFile(filePath).getLines().toList
    val movieDataLines = lines.tail

    var moviesList = List[Movie]()
    var actorsList = List[Actor]()
    var directorsList = List[Director]()

    movieDataLines.foreach { line =>
      val columns = line.split(",").map(_.trim)
      if (columns.length == 11) {
        try {
          val title = columns(0)
          val year = columns(1).toInt
          val runtime = columns(2).toInt
          val certificate = columns(3)
          val genre = columns(4)
          val directorNames = columns(5).stripPrefix("[").stripSuffix("]").split(",").map(_.trim).toList
          val starsNames = columns(6).stripPrefix("[").stripSuffix("]").split(",").map(_.trim).toList
          val rating = columns(7).toDouble
          val metascore = columns(8).toInt
          val votes = columns(9).toInt
          val gross = columns(10).toDouble

          // Création de l'instance de Director s'il n'existe pas déjà
          val director = directorsList.find(d => d.firstName == directorNames.head.split(" ")(0) && d.lastName == directorNames.head.split(" ")(1)) match {
            case Some(existingDirector) => existingDirector
            case None =>
              val directorName = directorNames.head.stripPrefix("'").stripSuffix("'")
              val newDirector = new Director(directorName.split(" ")(0), directorName.split(" ")(1), List())
              directorsList = newDirector :: directorsList
              newDirector
          }

          // Création des instances d'Actors s'ils n'existent pas déjà
          val stars = starsNames.map { starName =>
            actorsList.find(a => a.firstName == starName.stripPrefix("'").stripSuffix("'").split(" ")(0) && a.lastName == starName.stripPrefix("'").stripSuffix("'").split(" ")(1)) match {
              case Some(existingActor) => existingActor
              case None =>
                val actorName = starName.stripPrefix("'").stripSuffix("'")
                val newActor = new Actor(actorName.split(" ")(0), actorName.split(" ")(1), List())
                actorsList = newActor :: actorsList
                newActor
            }
          }

          // Création de l'instance de Movie
          val movie = new Movie(title, year, runtime, certificate, genre, director, stars, rating, metascore, votes, gross)
          // Affichage pour vérifier la création de l'objet Movie
          println(s"Création d'un film : Titre: $title, Année: $year, Note: $rating")
          // Ajout du film à la liste de films
          moviesList = movie :: moviesList

          // Mettre à jour les références dans les acteurs et le réalisateur
          director.movies = movie :: director.movies
          stars.foreach(actor => actor.movies = movie :: actor.movies)
        } catch {
          case e: Exception => println(s"Erreur lors de la création d'un film : ${e.getMessage}")
        }
      }
    }

    (moviesList, actorsList, directorsList)
  }
}
