package MovieTpPackage

//import com.github.tototoshi.csv._
// Movie.scala

class Movie(
             val title: String,
             val year: Int,
             val runtime: Int,
             val certificate: String,
             val genre: String,
             var director: Director,
             var stars: List[Actor],
             val rating: Double,
             val metascore: Int,
             val votes: Int,
             val gross: Double
           ) extends Comparable[Movie] {
  def compareTo(other: Movie): Int = {
    // Comparaison basée sur le rating (note) des films
    this.rating.compareTo(other.rating)
  }

  override def toString: String = {
    s"Title: $title\nYear: $year\nRuntime: $runtime minutes\nCertificate: $certificate\nGenre: $genre\nDirector: ${director.firstName} ${director.lastName}\nStars: ${stars.map(actor => s"${actor.firstName} ${actor.lastName}").mkString(", ")}\nRating: $rating\nMetascore: $metascore\nVotes: $votes\nGross: $$${gross}M"
  }

  // Méthode pour ajouter un acteur au film
  def addActor(actor: Actor): Unit = {
    stars = actor :: stars
  }
}

object Movie {
  def apply(
             title: String,
             year: Int,
             runtime: Int,
             certificate: String,
             genre: String,
             director: Director,
             stars: List[Actor],
             rating: Double,
             metascore: Int,
             votes: Int,
             gross: Double
           ): Movie = {
    new Movie(
      title,
      year,
      runtime,
      certificate,
      genre,
      director,
      stars,
      rating,
      metascore,
      votes,
      gross
    )
  }
}
