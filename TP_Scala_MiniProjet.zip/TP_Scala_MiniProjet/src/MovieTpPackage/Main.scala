package MovieTpPackage

//class Main {
//  // Utilisation :
//  val fileParser = FileParser.getInstance
//  val movies: List[Movie] = fileParser.parseMovies("chemin_vers_fichier.csv")
//  val actors: List[Actor] = fileParser.parseActors("chemin_vers_acteurs.csv")
//  val directors: List[Director] = fileParser.parseDirectors("chemin_vers_realisateurs.csv")
//}

import scala.io.Source

object Main {
  def main(args: Array[String]): Unit = {
    // Chemin du fichier CSV
    val filePath = "C:\\Users\\GLC\\Downloads\\moviesSemiCol\\moviesSemiCol.csv"
    println(s"Chemin du fichier CSV : $filePath")
    println("Veuillez penser à modifier le chemin du fichier et choisir un fichier avec pour séparateur les ;")
    // Lecture des lignes du fichier CSV avec le délimiteur ","
    val lines = io.Source.fromFile(filePath).getLines().toList

    // Afficher les lignes lues
    //println("Lignes du fichier .csv :")
    //lines.foreach(println)

    // Supprimer l'en-tête (première ligne) si nécessaire
    val movieDataLines = lines.tail

    // Liste pour stocker les instances de films
    var moviesList = List[Movie]()

    // Liste pour stocker les instances d'acteurs
    var actorsList = List[Actor]()

    // Liste pour stocker les instances de réalisateurs
    var directorsList = List[Director]()
    var directorName = ""
    var starsNames = List[String]()

    // Analyse des lignes de données du fichier CSV
    movieDataLines.foreach { line =>
      val columns = line.split(";").map(_.trim)
      if (columns.length == 11) {
        try {
          val title = columns(0)
          val year = columns(1).toInt
          val runtime = columns(2).toInt
          val certificate = columns(3)
          val genre = columns(4)
          val directorNames = columns(5).stripPrefix("[").stripSuffix("]").split(",").map(_.trim).toList
          val starsNames = columns(6).stripPrefix("[").stripSuffix("]").split(",").map(_.trim).toList
          val rating = columns(7).replace(",", ".").toDouble
          val metascore = columns(8).toInt
          val votes = columns(9).toInt
          val gross = columns(10).replace(",", ".").toDouble

          // Création de l'instance de Director s'il n'existe pas déjà
          val director = directorsList.find(d => d.firstName == directorNames.head.split(" ")(0) && d.lastName == directorNames.head.split(" ")(1)) match {
            case Some(existingDirector) => existingDirector
            case None =>
              val directorName = directorNames.head.stripPrefix("'").stripSuffix("'")
              val newDirector = new Director(directorName.split(" ")(0), directorName.split(" ")(1), List())
              directorsList = newDirector :: directorsList
              newDirector
          }

          // Création des instances d'Actors s'ils n'existent pas déjà
          val stars = starsNames.map { starName =>
            actorsList.find(a => a.firstName == starName.stripPrefix("'").stripSuffix("'").split(" ")(0) && a.lastName == starName.stripPrefix("'").stripSuffix("'").split(" ")(1)) match {
              case Some(existingActor) => existingActor
              case None =>
                val actorName = starName.stripPrefix("'").stripSuffix("'")
                val newActor = new Actor(actorName.split(" ")(0), actorName.split(" ")(1), List())
                actorsList = newActor :: actorsList
                newActor
            }
          }

          // Création de l'instance de Movie
          val movie = new Movie(title, year, runtime, certificate, genre, director, stars, rating, metascore, votes, gross)
          // Affichage pour vérifier la création de l'objet Movie
          println(s"Création d'un film réussi: Titre: $title, Année: $year, Note: $rating")

          // Ajout du film à la liste de films
          moviesList = movie :: moviesList

          // Mettre à jour les références dans les acteurs et le réalisateur
          director.movies = movie :: director.movies
          stars.foreach(actor => actor.movies = movie :: actor.movies)
        } catch {
          case e: Exception =>
          //            println(s"Erreur lors de la création d'un film : ${e.getMessage}")
        }
      }
    }

    // Affichage pour vérifier la création de l'objet Director
    println(s"Création d'un réalisateur : Nom: $directorName")
    // Affichage pour vérifier la création de l'objet Actor
    println(s"Création d'un acteur : Noms: ${starsNames.mkString(", ")}")

    // Création de la cinémathèque avec la liste de films
    val movieSet = new Cinema(moviesList)

    // A) Obtenez les 20 meilleurs réalisateurs avec la meilleure moyenne de leurs films
    val topDirectors = movieSet.topDirectors(20)
    println("Les 20 meilleurs réalisateurs :")
    topDirectors.foreach(director => println(s"${director.firstName} ${director.lastName} - Moyenne: ${director.averageRating}"))

    // B) Obtenez une cinémathèque de films récents (sortis en 2015 et après)
    val recentMoviesSet = movieSet.recentMovies
    println("\nCinémathèque de films récents (2015 et après):")
    recentMoviesSet.movies.foreach(movie => println(s"${movie.title} (${movie.year})"))

    // C) Obtenez une cinémathèque de films avec une note supérieure à 8
    val highRatedMoviesSet = movieSet.highRatedMovies
    println("\nCinémathèque de films avec une note supérieure à 8:")
    highRatedMoviesSet.movies.foreach(movie => println(s"${movie.title} - Note: ${movie.rating}"))

    // D) Obtenez une cinémathèque de films par genre (critère personnalisé)
    val actionMoviesSet = movieSet.moviesByGenre("Action")
    println("\nCinémathèque de films d'Action:")
    actionMoviesSet.movies.foreach(movie => println(s"${movie.title} - Genre: ${movie.genre}"))

    // Vous pouvez maintenant utiliser la cinémathèque (movieSet) et le registre (register) pour manipuler les données.
    // Affichage pour vérifier la taille des listes après ajout d'un film
    println(s"Taille de moviesList : ${moviesList.length}")
    println(s"Taille de actorsList : ${actorsList.length}")
    println(s"Taille de directorsList : ${directorsList.length}")
    println(s"Voici la moviesList : ${moviesList}")
  }
}
